﻿using PROMetell.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PROMetell.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditBrigadePage.xaml
    /// </summary>
    public partial class AddEditBrigadePage : Page
    {
        Brigade editBrigade;
        bool isExist = true;
        User user;
        public AddEditBrigadePage(User currentUser)
        {
            InitializeComponent();
            isExist = false;
            user = currentUser;
            editBrigade = new Brigade();
        }

        public AddEditBrigadePage(Brigade brigade, User currentUser)
        {
            InitializeComponent();
            editBrigade = brigade;
            user = currentUser;
            if (editBrigade != null)
            {
                BrigadeNumTextBox.IsEnabled = false;
                BrigadeLabel.Content = "Изменение бригады";
                AddBrigadeButton.Content = "Изменить данные";
            }
        }
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            this.DataContext = editBrigade;
        }
        private void AddBrigadeButton_Click(object sender, RoutedEventArgs e)
        {
            if (!isExist && BrigadeNumTextBox != null && BrigadeNameTextBox != null)
            {
                try
                {
                    DB.DB.entities.Brigade.Add(editBrigade);
                    DB.DB.entities.SaveChanges();
                    MessageBox.Show("Бригада успешно добавлена!", "Запись сохранена", MessageBoxButton.OK, MessageBoxImage.Information);
                    NavigationService.Navigate(new WorkerPage(user));
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка, проверьте правильность заполнения полей.", "Запись не сохранена", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else if (BrigadeNumTextBox != null && BrigadeNameTextBox != null)
            {
                try
                {
                    DB.DB.entities.SaveChanges();
                    MessageBox.Show("Информация о бригаде успешно изменена!", "Запись сохранена", MessageBoxButton.OK, MessageBoxImage.Information);
                    NavigationService.Navigate(new WorkerPage(user));
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка, проверьте правильность заполнения полей.", "Запись не сохранена", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Запись не была сохранена всвязи с отсутствием данных в полях. Проверьте, все ли поля заполнены, и попробуйте снова.", "Ошибка сохранения данных", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void GoBackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new WorkerPage(user));
        }
    }
}
