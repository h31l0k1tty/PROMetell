﻿using PROMetell.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PROMetell.Pages
{
    /// <summary>
    /// Логика взаимодействия для AuthPage.xaml
    /// </summary>
    public partial class AuthPage : Page
    {
        public AuthPage()
        {
            InitializeComponent();
        }
        User loginUser;
        private void AuthButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                loginUser = DB.DB.entities.User.FirstOrDefault(c => c.UserLogin == LoginTextBox.Text && c.UserPassword == PasswordBox.Password);
                if (loginUser != null)
                {
                    string userLastName = loginUser.Worker.WorkerLastName;
                    string userName = loginUser.Worker.WorkerName;
                    //role 2 = administrator
                    if (loginUser != null && loginUser.RoleId == 2)
                    {
                        NavigationService.Navigate(new JobCardPage(loginUser));
                    }
                    //role 1 = technologyst
                    else if (loginUser != null && loginUser.RoleId == 1 || loginUser.RoleId == 7)
                    {
                        MessageBox.Show($"Вход выполнен под именем: {userLastName} {userName}", "Вход в систему", MessageBoxButton.OK, MessageBoxImage.Information);
                        NavigationService.Navigate(new JobCardPage(loginUser));
                    }
                }
                else
                {
                    MessageBox.Show("Произошла ошибка авторизации. Проверьте логин и пароль.", "Ошибка авторизации", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch
            {
                MessageBox.Show("Произошла неизвестная ошибка. Пожалуйста, повторите попытку позже.", "Неизвестная ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
