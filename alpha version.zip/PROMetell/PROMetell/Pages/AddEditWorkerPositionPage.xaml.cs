﻿using PROMetell.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PROMetell.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditWorkerPositionPage.xaml
    /// </summary>
    public partial class AddEditWorkerPositionPage : Page
    {
        public WorkerPosition editWorkerPosition;
        public User user;
        bool isExist = true;
        public AddEditWorkerPositionPage(User currentUser)
        {
            InitializeComponent();
            user = currentUser;
            isExist = false;
            editWorkerPosition = new WorkerPosition();
        }
        public AddEditWorkerPositionPage(WorkerPosition currentWP, User currentUser)
        {
            InitializeComponent();
            editWorkerPosition = currentWP;
            user = currentUser;
            if (editWorkerPosition != null)
            {
                WorkerPositionIdTextBox.IsEnabled = false;
                WorkerPositionLabel.Content = "Изменение должности";
                AddWorkerPositionButton.Content = "Изменить должность";
            }
        }
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            this.DataContext = editWorkerPosition;
        }
        private void WorkerPositionIdTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9.]+");
            e.Handled = regex.IsMatch(e.Text);
        }
        private void GoBackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new WorkerPage(user));
        }
        private void AddWorkerPositionButton_Click(object sender, RoutedEventArgs e)
        {
            if (!isExist && WorkerPositionIdTextBox.Text != null && WorkerPositionNameTextBox.Text != null)
            {
                try
                {
                    DB.DB.entities.WorkerPosition.Add(editWorkerPosition);
                    DB.DB.entities.SaveChanges();
                    MessageBox.Show("Должность успешно добавлена!", "Запись сохранена", MessageBoxButton.OK, MessageBoxImage.Information);
                    NavigationService.Navigate(new WorkerPage(user));
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка, проверьте правильность заполнения полей.", "Запись не сохранена", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else if (WorkerPositionIdTextBox.Text != null && WorkerPositionNameTextBox.Text != null)
            {
                try
                {
                    DB.DB.entities.SaveChanges();
                    MessageBox.Show("Информация о должности успешно изменена!", "Запись сохранена", MessageBoxButton.OK, MessageBoxImage.Information);
                    NavigationService.Navigate(new WorkerPage(user));
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка, проверьте правильность заполнения полей.", "Запись не сохранена", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Запись не была сохранена всвязи с отсутствием данных в полях. Проверьте, все ли поля заполнены, и попробуйте снова.", "Ошибка сохранения данных", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
