﻿using PROMetell.DB;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Text.RegularExpressions;

namespace PROMetell.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditJobCardPage.xaml
    /// </summary>
    public partial class AddEditJobCardPage : Page
    {
        JobCard editJobCard;
        User loginUser;
        bool isExist = true;
        public AddEditJobCardPage(User user)
        {
            InitializeComponent();
            isExist = false;
            loginUser = user;
            editJobCard = new JobCard();
            WorkPlaceComboBox.ItemsSource = DB.DB.entities.Workplace.ToList();
            ProductComboBox.ItemsSource = DB.DB.entities.Product.ToList();
            DatePicker currentDate = new DatePicker();
            currentDate.SelectedDate = DateTime.Today;
            JobCardDatePicker.SelectedDate = currentDate.SelectedDate;
        }
        public AddEditJobCardPage(JobCard currentJobCard, User user)
        {
            InitializeComponent();
            editJobCard = currentJobCard;
            loginUser = user;
            WorkPlaceComboBox.ItemsSource = DB.DB.entities.Workplace.ToList();
            ProductComboBox.ItemsSource = DB.DB.entities.Product.ToList();
            if (editJobCard != null)
            {
                JobCardIdTextBox.IsEnabled = false;
                JobCardLabel.Content = "Изменение наряда";
                AddJobCardButton.Content = "Изменить данные";
                JobCardDatePicker.SelectedDate = editJobCard.JobCardDate;
            }
        }
        private void JobCardDatePicker_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9.]+");
            e.Handled = regex.IsMatch(e.Text);
        }
        private void JobCardIdTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9.]+");
            e.Handled = regex.IsMatch(e.Text);
        }
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            this.DataContext = editJobCard;
        }

        private void WorkPlaceComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            editJobCard.Workplace = (Workplace)WorkPlaceComboBox.SelectedItem;
        }

        private void ProductComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            editJobCard.Product = (Product)ProductComboBox.SelectedItem;
        }

        private void AddJobCardButton_Click(object sender, RoutedEventArgs e)
        {
            if (!isExist && JobCardIdTextBox.Text != null && WorkPlaceComboBox.SelectedItem != null && ProductComboBox.SelectedItem != null)
            {
                try
                {
                    editJobCard.JobCardDate = JobCardDatePicker.SelectedDate.Value.Date;
                    DB.DB.entities.JobCard.Add(editJobCard);
                    DB.DB.entities.SaveChanges();
                    MessageBox.Show("Наряд успешно добавлен!", "Запись сохранена", MessageBoxButton.OK, MessageBoxImage.Information);
                    NavigationService.Navigate(new JobCardPage(loginUser));
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка, проверьте правильность заполнения полей.", "Запись не сохранена", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else if (JobCardIdTextBox.Text != null && WorkPlaceComboBox.SelectedItem != null && ProductComboBox.SelectedItem != null)
            {
                try
                {
                    editJobCard.JobCardDate = JobCardDatePicker.SelectedDate.Value.Date;
                    DB.DB.entities.SaveChanges();
                    MessageBox.Show("Информация о наряде успешно изменена!", "Запись сохранена", MessageBoxButton.OK, MessageBoxImage.Information);
                    NavigationService.Navigate(new JobCardPage(loginUser));
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка, проверьте правильность заполнения полей.", "Запись не сохранена", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Запись не была сохранена всвязи с отсутствием данных в полях. Проверьте, все ли поля заполнены, и попробуйте снова.", "Ошибка сохранения данных", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void GoBackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new JobCardPage(loginUser));
        }
    }
}
