﻿using PROMetell.DB;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Xceed.Document.NET;
using Xceed.Words.NET;

namespace PROMetell.Pages
{
    /// <summary>
    /// Логика взаимодействия для JobCardPage.xaml
    /// </summary>
    public partial class JobCardPage : Page
    {
        User user;
        public JobCardPage(User loginUser)
        {
            InitializeComponent();
            JobCardListView.ItemsSource = DB.DB.entities.JobCard.ToList();
            RouteSheetListView.ItemsSource = DB.DB.entities.RouteSheet.ToList();
            user = loginUser;
            if (user.RoleId == 1)
            {
                ButtonsStackPanel.Visibility = Visibility.Collapsed;
            }
            if (user.RoleId == 7)
            {
                AllStackPanel.Width = 650;
                AllStackPanel.Height = 655;
                ButtonsStackPanel.Visibility = Visibility.Collapsed;
                RouteSheetStackPanel.Visibility = Visibility.Collapsed;
            }
        }
        private void FullInfoRight_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                JobCardFullInfoWindow jobCardFullInfoWindow = new JobCardFullInfoWindow(currentJobCard, user);
                jobCardFullInfoWindow.Show();
            }
            catch
            {
                MessageBox.Show("Для данного наряда не было добавлено ни одной записи, доступной для просмотра.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.None);
            }
        }
        public JobCard currentJobCard;
        private void JobCardListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            currentJobCard = (JobCard)JobCardListView.SelectedItem;
        }
        //right click abilities
        private void AddJobCardRightClick_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddEditJobCardPage(user));
        }
        private void EditJobCardRightClick_Click(object sender, RoutedEventArgs e)
        {
            if (currentJobCard == null)
            {
                MessageBox.Show("Произошла ошибка. Пожалуйста, выберите запись, которую вы хотите изменить.", "Операция прервана", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
            else
            {
                NavigationService.Navigate(new AddEditJobCardPage(currentJobCard, user));
            }
        }
        private void DeleteJobCardRightClick_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (currentJobCard == null)
                {
                    MessageBox.Show("Произошла ошибка. Пожалуйста, выберите запись, которую вы хотите удалить.", "Ошибка удаления записи", MessageBoxButton.OK, MessageBoxImage.Stop);
                }
                else if (MessageBox.Show("Вы уверены, что хотите удалить запись?", "Удаление заказа", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    try
                    {
                        JobCard jc = JobCardListView.SelectedItem as JobCard;
                        DB.DB.entities.JobCardTablePart.RemoveRange(jc.JobCardTablePart);
                        DB.DB.entities.JobCard.Remove(jc);
                        DB.DB.entities.SaveChanges();
                        MessageBox.Show("Запись успешно удалена.", "Запись удалена", MessageBoxButton.OK, MessageBoxImage.Information);
                        JobCardListView.ItemsSource = DB.DB.entities.JobCard.ToList();
                    }
                    catch
                    {
                        MessageBox.Show("Произошла ошибка. Пожалуйста, повторите попытку позже.", "Неизвестная ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            catch
            {
                MessageBox.Show("Произошла неизвестная ошибка. Пожалуйста, повторите попытку позднее.", "Неизвестная ошибка", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
        }
        private void RouteSheetFullInfoRight_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                RouteSheetFullInfoWindow routeSheetFullInfoWindow = new RouteSheetFullInfoWindow(currentRouteSheet, user);
                routeSheetFullInfoWindow.Show();
            }
            catch
            {
                MessageBox.Show("Детали маршрутной карты не найдены.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.None);
            }
        }
        private void SearchJobCardTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                if (SearchJobCardTextBox.Text != null && SearchJobCardTextBox.Text != "" && SearchJobCardTextBox.Text != " ")
                {
                    JobCardListView.ItemsSource = DB.DB.entities.JobCard.Where(c => c.ProductNum.Contains(SearchJobCardTextBox.Text)).ToList();
                    if (JobCardListView.HasItems == false)
                    {
                        MessageBox.Show("Не найдено ни одной записи.", "Запись отсутствует", MessageBoxButton.OK, MessageBoxImage.None);
                        SearchJobCardTextBox.Text = string.Empty;
                        JobCardListView.ItemsSource = DB.DB.entities.JobCard.ToList();
                    }
                }
                else
                {
                    JobCardListView.ItemsSource = DB.DB.entities.JobCard.ToList();
                }
            }
            catch (Exception error)
            {
                MessageBox.Show("Произошла ошибка поиска записей. Пожалуйста, повторите попытку позднее.", "Ошибка поиска данных", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
        }

        public RouteSheet currentRouteSheet;
        private void RouteSheetListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            currentRouteSheet = (RouteSheet)RouteSheetListView.SelectedItem;
        }
        private void AddRouteSheetRightClick_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddEditRouteSheetPage(user));
        }
        private void EditRouteSheetRightClick_Click(object sender, RoutedEventArgs e)
        {
            if (currentRouteSheet == null)
            {
                MessageBox.Show("Произошла ошибка. Пожалуйста, выберите запись, которую вы хотите изменить.", "Операция прервана", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
            else
            {
                NavigationService.Navigate(new AddEditRouteSheetPage(currentRouteSheet, user));
            }
        }
        private void DeleteRouteSheetRightClick_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (currentRouteSheet == null)
                {
                    MessageBox.Show("Произошла ошибка. Пожалуйста, выберите запись, которую вы хотите удалить.", "Ошибка удаления записи", MessageBoxButton.OK, MessageBoxImage.Stop);
                }
                else if (MessageBox.Show("Вы уверены, что хотите удалить запись?", "Удаление маршрутной карты", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    try
                    {
                        RouteSheet routeSheet = RouteSheetListView.SelectedItem as RouteSheet;
                        DB.DB.entities.OperationList.RemoveRange(routeSheet.OperationList);
                        DB.DB.entities.RouteSheet.Remove(routeSheet);
                        DB.DB.entities.SaveChanges();
                        MessageBox.Show("Запись успешно удалена.", "Запись удалена", MessageBoxButton.OK, MessageBoxImage.Information);
                        RouteSheetListView.ItemsSource = DB.DB.entities.RouteSheet.ToList();
                    }
                    catch
                    {
                        MessageBox.Show("Произошла ошибка. Пожалуйста, повторите попытку позже.", "Неизвестная ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            catch
            {
                MessageBox.Show("Произошла неизвестная ошибка. Пожалуйста, повторите попытку позднее.", "Неизвестная ошибка", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
        }
        private void SearchRouteSheetTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                if (SearchRouteSheetTextBox.Text != null && SearchRouteSheetTextBox.Text != "" && SearchRouteSheetTextBox.Text != " ")
                {
                    RouteSheetListView.ItemsSource = DB.DB.entities.RouteSheet.Where(c => c.ProductNum.Contains(SearchRouteSheetTextBox.Text)).ToList();
                    if (RouteSheetListView.HasItems == false)
                    {
                        MessageBox.Show("Не найдено ни одной записи.", "Запись отсутствует", MessageBoxButton.OK, MessageBoxImage.None);
                        SearchRouteSheetTextBox.Text = string.Empty;
                        RouteSheetListView.ItemsSource = DB.DB.entities.RouteSheet.ToList();
                    }
                }
                else
                {
                    RouteSheetListView.ItemsSource = DB.DB.entities.RouteSheet.ToList();
                }
            }
            catch (Exception error)
            {
                MessageBox.Show("Произошла ошибка поиска записей. Пожалуйста, повторите попытку позднее.", "Ошибка поиска данных", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
        }
        private void OrderPageButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new OrderPage(user));
        }
        private void ProductPageButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ProductPage(user));
        }
        private void WorkerPageButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new WorkerPage(user));
        }
        private void GoBackButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (MessageBox.Show("Вы уверены, что хотите выйти из аккаунта?", "Выход", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    NavigationService.Navigate(new AuthPage());
                }
            }
            catch
            {
                MessageBox.Show("Произошла неизвестная ошибка. Пожалуйста, повторите попытку позднее.", "Неизвестная ошибка", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
        }
    }
}
