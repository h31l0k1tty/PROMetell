﻿using PROMetell.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PROMetell.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditJobCardTablePartPage.xaml
    /// </summary>
    public partial class AddEditJobCardTablePartPage : Page
    {
        JobCardTablePart editJobCardTablePart;
        JobCard currentJobCard;
        User loginUser;
        bool isExist = true;
        public AddEditJobCardTablePartPage(JobCard jobCard, User user)
        {
            InitializeComponent();
            editJobCardTablePart = new JobCardTablePart();
            currentJobCard = jobCard;
            isExist = false;
            WorkerComboBox.ItemsSource = DB.DB.entities.Worker.ToList();
            OperationComboBox.ItemsSource = DB.DB.entities.Operation.ToList();
            JobCardIdTextBox.Text = Convert.ToString(currentJobCard.JobCardId);
            JobCardIdTextBox.IsEnabled = false;
            loginUser = user;
            AddOperationListButton.Visibility = Visibility.Collapsed;
            OperationListComboBox.Visibility = Visibility.Collapsed;
        }
        public AddEditJobCardTablePartPage(JobCard jobCard, JobCardTablePart jobCardTablePart, User user)
        {
            InitializeComponent();
            currentJobCard = jobCard;
            editJobCardTablePart = jobCardTablePart;
            WorkerComboBox.ItemsSource = DB.DB.entities.Worker.ToList();
            OperationComboBox.ItemsSource = DB.DB.entities.Operation.ToList();
            JobCardIdTextBox.Text = Convert.ToString(currentJobCard.JobCardId);
            JobCardTablePartIdTextBox.Text = Convert.ToString(editJobCardTablePart.JobCardTablePartId);
            if (editJobCardTablePart != null)
            {
                JobCardTablePartIdTextBox.IsEnabled = false;
                JobCardIdTextBox.IsEnabled = false;
                OperationLabel.Content = "Изменение операции";
                AddJobCardTablePartButton.Content = "Изменить данные";
            }
            AddOperationListButton.Visibility = Visibility.Collapsed;
            OperationListComboBox.Visibility = Visibility.Collapsed;
        }
        RouteSheet routeSheet;
        OperationList editOperationList;
        public AddEditJobCardTablePartPage(RouteSheet currentRouteSheet, User user)
        {
            InitializeComponent();
            routeSheet = currentRouteSheet;
            editOperationList = new OperationList();
            JobCardIdTextBox.Text = Convert.ToString(routeSheet.RouteSheetNum);
            JobCardIdTextBox.IsEnabled = false;
            OperationListComboBox.ItemsSource = DB.DB.entities.Operation.ToList();
            isExist = false;
            WorkerComboBox.Visibility = Visibility.Collapsed;
            WorkerTextBlock.Visibility = Visibility.Collapsed;
            OperationNumOrOperationListNIdTextBlock.Text = "Номер листа:";
            JobCardNumOrRouteSheetNumTextBlock.Text = "Номер маршрутной карты:";
            AddJobCardTablePartButton.Visibility = Visibility.Collapsed;
            OperationComboBox.Visibility = Visibility.Collapsed;
        }
        public AddEditJobCardTablePartPage(RouteSheet currentRouteSheet, OperationList operationList, User user)
        {
            InitializeComponent();
            routeSheet = currentRouteSheet;
            loginUser = user;
            editOperationList = operationList;
            JobCardTablePartIdTextBox.Text = Convert.ToString(editOperationList.OperationListId);
            JobCardTablePartIdTextBox.IsEnabled = false;
            JobCardIdTextBox.Text = Convert.ToString(editOperationList.RouteSheetNum);
            JobCardIdTextBox.IsEnabled = false;
            OperationListComboBox.ItemsSource = DB.DB.entities.Operation.ToList();
            WorkerComboBox.Visibility = Visibility.Collapsed;
            WorkerTextBlock.Visibility = Visibility.Collapsed;
            OperationNumOrOperationListNIdTextBlock.Text = "Номер листа:";
            JobCardNumOrRouteSheetNumTextBlock.Text = "Номер маршрутной карты:";
            OperationLabel.Content = "Изменение операции";
            AddJobCardTablePartButton.Content = "Изменить данные";
            AddJobCardTablePartButton.Visibility = Visibility.Collapsed;
            OperationComboBox.Visibility = Visibility.Collapsed;
        }
        private void JobCardTablePartIdTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9.]+");
            e.Handled = regex.IsMatch(e.Text);
        }
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            if (editJobCardTablePart != null)
            {
                this.DataContext = editJobCardTablePart;
            }
            else
            {
                this.DataContext = editOperationList;
            }
        }
        private void WorkerComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            editJobCardTablePart.Worker = (Worker)WorkerComboBox.SelectedItem;
        }

        private void OperationComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            editJobCardTablePart.Operation = (Operation)OperationComboBox.SelectedItem;
        }
        private void OperationListComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            editOperationList.Operation = (Operation)OperationListComboBox.SelectedItem;
        }
        private void AddJobCardTablePartButton_Click(object sender, RoutedEventArgs e)
        {
            if (!isExist && JobCardIdTextBox.Text != null && JobCardTablePartIdTextBox.Text != null && WorkerComboBox.SelectedItem != null && OperationComboBox.SelectedItem != null)
            {
                try
                {
                    editJobCardTablePart.JobCardTablePartId = Convert.ToInt32(JobCardTablePartIdTextBox.Text);
                    editJobCardTablePart.JobCardId = Convert.ToInt32(JobCardIdTextBox.Text);
                    DB.DB.entities.JobCardTablePart.Add(editJobCardTablePart);
                    DB.DB.entities.SaveChanges();
                    MessageBox.Show("Операция успешно добавлена!", "Запись сохранена", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка, проверьте правильность заполнения полей.", "Запись не сохранена", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else if (JobCardIdTextBox.Text != null && WorkerComboBox.SelectedItem != null && OperationComboBox.SelectedItem != null)
            {
                try
                {
                    editJobCardTablePart.JobCardTablePartId = Convert.ToInt32(JobCardTablePartIdTextBox.Text);
                    editJobCardTablePart.JobCardId = Convert.ToInt32(JobCardIdTextBox.Text);
                    DB.DB.entities.SaveChanges();
                    MessageBox.Show("Информация об операции успешно изменена!", "Запись сохранена", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка, проверьте правильность заполнения полей.", "Запись не сохранена", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Запись не была сохранена всвязи с отсутствием данных в полях. Проверьте, все ли поля заполнены, и попробуйте снова.", "Ошибка сохранения данных", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void AddOperationListButton_Click(object sender, RoutedEventArgs e)
        {
            if (!isExist && JobCardIdTextBox.Text != null && JobCardTablePartIdTextBox.Text != null && OperationListComboBox.SelectedItem != null)
            {
                try
                {
                    editOperationList.OperationListId = Convert.ToInt32(JobCardTablePartIdTextBox.Text);
                    editOperationList.RouteSheetNum = JobCardIdTextBox.Text;
                    DB.DB.entities.OperationList.Add(editOperationList);
                    DB.DB.entities.SaveChanges();
                    MessageBox.Show("Операция успешно добавлена!", "Запись сохранена", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка, проверьте правильность заполнения полей.", "Запись не сохранена", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else if (JobCardIdTextBox.Text != null && JobCardTablePartIdTextBox.Text != null && OperationListComboBox.SelectedItem != null)
            {
                try
                {
                    editOperationList.OperationListId = Convert.ToInt32(JobCardTablePartIdTextBox.Text);
                    editOperationList.RouteSheetNum = JobCardIdTextBox.Text;
                    DB.DB.entities.SaveChanges();
                    MessageBox.Show("Информация об операции успешно изменена!", "Запись сохранена", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка, проверьте правильность заполнения полей.", "Запись не сохранена", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Запись не была сохранена всвязи с отсутствием данных в полях. Проверьте, все ли поля заполнены, и попробуйте снова.", "Ошибка сохранения данных", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
