﻿using PROMetell.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PROMetell.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditProductPage.xaml
    /// </summary>
    public partial class AddEditProductPage : Page
    {
        Product editProduct;
        User user;
        bool isExist = true;
        public AddEditProductPage(User loginUser)
        {
            InitializeComponent();
            user = loginUser;
            editProduct = new Product();
            isExist = false;
        }
        public AddEditProductPage(User loginUser, Product currentProduct)
        {
            InitializeComponent();
            user = loginUser;
            editProduct = currentProduct;
            if (editProduct != null)
            {
                ProductNumTextBox.IsEnabled = false;
                ProductLabel.Content = "Изменение изделия";
                AddProductButton.Content = "Изменить изделие";
            }
        }
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            this.DataContext = editProduct;
        }

        private void AddProductButton_Click(object sender, RoutedEventArgs e)
        {
            if (!isExist && ProductNumTextBox.Text != null && ProductNameTextBox.Text != null)
            {
                try
                {
                    DB.DB.entities.Product.Add(editProduct);
                    DB.DB.entities.SaveChanges();
                    MessageBox.Show("Изделие успешно добавлено!", "Запись сохранена", MessageBoxButton.OK, MessageBoxImage.Information);
                    NavigationService.Navigate(new ProductPage(user));
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка, проверьте правильность заполнения полей.", "Запись не сохранена", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else if (ProductNumTextBox.Text != null && ProductNameTextBox.Text != null)
            {
                try
                {
                    DB.DB.entities.SaveChanges();
                    MessageBox.Show("Информация об изделии успешно изменена!", "Запись сохранена", MessageBoxButton.OK, MessageBoxImage.Information);
                    NavigationService.Navigate(new ProductPage(user));
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка, проверьте правильность заполнения полей.", "Запись не сохранена", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Запись не была сохранена всвязи с отсутствием данных в полях. Проверьте, все ли поля заполнены, и попробуйте снова.", "Ошибка сохранения данных", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void GoBackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ProductPage(user));
        }
    }
}
