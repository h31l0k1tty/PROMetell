﻿using PROMetell.DB;
using PROMetell.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Xceed.Document.NET;
using Xceed.Words.NET;

namespace PROMetell
{
    /// <summary>
    /// Логика взаимодействия для RouteSheetFullInfoWindow.xaml
    /// </summary>
    public partial class RouteSheetFullInfoWindow : Window
    {
        public User loginUser;
        public RouteSheet currentRouteSheet = new RouteSheet();
        public string routeSheetNum;
        public RouteSheetFullInfoWindow(RouteSheet routeSheet, User user)
        {
            InitializeComponent();
            loginUser = user;
            currentRouteSheet = routeSheet;
            var currentRouteSheetNum = currentRouteSheet.RouteSheetNum;
            routeSheetNum = currentRouteSheetNum;
            RouteSheetFullInfoListView.ItemsSource = DB.DB.entities.OperationList.Where(c => c.RouteSheetNum == currentRouteSheetNum).ToList();
            RouteSheetNumLabel.Content = routeSheetNum;
            ProductNumLabel.Content = currentRouteSheet.ProductNum.ToString();
            ProductNameLabel.Content = currentRouteSheet.Product.ProductName.ToString();
            WorkpieceCountLabel.Content = currentRouteSheet.WorkpieceCount.ToString();
            CompletedDateLabel.Content = currentRouteSheet.CompletedDate.ToString();
            if (RouteSheetFullInfoListView.HasItems == false)
            {
                NoListLabel.Visibility = Visibility.Visible;
            }
        }
        OperationList operationList;
        private void RouteSheetFullInfoListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            operationList = (OperationList)RouteSheetFullInfoListView.SelectedItem;
        }
        private void AddOperationRightClick_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            mainWindow.MainFrame.NavigationService.Navigate(new AddEditJobCardTablePartPage(currentRouteSheet, loginUser));
        }

        private void EditOperationRightClick_Click(object sender, RoutedEventArgs e)
        {
            if (operationList != null)
            {
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
                mainWindow.MainFrame.NavigationService.Navigate(new AddEditJobCardTablePartPage(currentRouteSheet, operationList, loginUser));
            }
            else
            {
                MessageBox.Show("Произошла ошибка. Пожалуйста, выберите запись, которую вы хотите изменить.", "Операция прервана", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
        }

        private void DeleteOperationRightClick_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (operationList == null)
                {
                    MessageBox.Show("Произошла ошибка. Пожалуйста, выберите запись, которую вы хотите удалить.", "Ошибка удаления записи", MessageBoxButton.OK, MessageBoxImage.Stop);
                }
                else if (MessageBox.Show("Вы уверены, что хотите удалить запись?", "Удаление операции", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    try
                    {
                        OperationList deleteOperationList = RouteSheetFullInfoListView.SelectedItem as OperationList;
                        DB.DB.entities.OperationList.Remove(deleteOperationList);
                        DB.DB.entities.SaveChanges();
                        MessageBox.Show("Запись успешно удалена.", "Запись удалена", MessageBoxButton.OK, MessageBoxImage.Information);
                        RouteSheetFullInfoListView.ItemsSource = DB.DB.entities.OperationList.Where(c => c.RouteSheetNum == currentRouteSheet.RouteSheetNum).ToList();
                    }
                    catch
                    {
                        MessageBox.Show("Произошла ошибка. Пожалуйста, повторите попытку позже.", "Неизвестная ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            catch
            {
                MessageBox.Show("Произошла неизвестная ошибка. Пожалуйста, повторите попытку позднее.", "Неизвестная ошибка", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
        }
        private void ReplaceKeywordWithValue(DocX document, string keyword, string value)
        {
            foreach (var paragraph in document.Paragraphs)
            {
                if (paragraph.Text.Contains(keyword))
                {
                    paragraph.ReplaceText(keyword, value);
                }
            }
        }
        private void AddItemToTable(int number, Xceed.Document.NET.Table table, Row rowPatternHigh, OperationList operationList)
        {
            //заполнение табличной части документа
            var newItemHigh = table.InsertRow(rowPatternHigh, table.RowCount - 1);
            newItemHigh.ReplaceText(new StringReplaceTextOptions() { SearchValue = "%NUM%", NewValue = number.ToString() });
            newItemHigh.ReplaceText(new StringReplaceTextOptions() { SearchValue = "%NAME%", NewValue = operationList.Operation.OperationName });
        }
        private void PrintButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (currentRouteSheet != null)
                {
                    using (var templateDoc = DocX.Load(@"C:\Users\semyo\Desktop\PROMetell\PROMetell\Properties\Route_sheet_example.docx"))
                    {
                        //заполнение шапки документа
                        string orderId = currentRouteSheet.OrderNum.ToString();
                        string productId = currentRouteSheet.ProductNum.ToString();
                        string productName = currentRouteSheet.Product.ProductName.ToString();
                        string workpieceCount = currentRouteSheet.WorkpieceCount.ToString();
                        string dateRouteSheet = currentRouteSheet.CompletedDate.ToString();
                        ReplaceKeywordWithValue(templateDoc, "{1}", orderId);
                        ReplaceKeywordWithValue(templateDoc, "{2}", productId);
                        ReplaceKeywordWithValue(templateDoc, "{3}", productName);
                        ReplaceKeywordWithValue(templateDoc, "{4}", workpieceCount);
                        ReplaceKeywordWithValue(templateDoc, "{5}", dateRouteSheet);
                        var reportTable = templateDoc.Tables[1];
                        var rowPatternHigh = reportTable.Rows[1];
                        //var rowPatternLow = reportTable.Rows[3];
                        int counter = 1;
                        var table_parts = DB.DB.entities.OperationList.Where(c => c.RouteSheetNum == currentRouteSheet.RouteSheetNum);
                        foreach (var item in table_parts)
                        {
                            AddItemToTable(counter, reportTable, rowPatternHigh, item);
                            counter++;
                        }
                        rowPatternHigh.Remove();
                        //rowPatternLow.Remove();
                        templateDoc.SaveAs($@"{Environment.GetFolderPath(Environment.SpecialFolder.Desktop)}\Маршрутная карта No_{orderId}");
                        MessageBox.Show("Маршрутная карта успешно сформирована. Вы можете найти её на рабочем столе.", "Формирование документа прошло успешно", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Произошла ошибка формирования маршрутной карты. Пожалуйста, повторите попытку позднее.", "Ошибка формирования МК", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ReloadButton_Click(object sender, RoutedEventArgs e)
        {
            RouteSheetFullInfoListView.ItemsSource = DB.DB.entities.OperationList.Where(c => c.RouteSheetNum == currentRouteSheet.RouteSheetNum).ToList();
        }
    }
}
