﻿using PROMetell.DB;
using PROMetell.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Xceed.Document.NET;
using Xceed.Words.NET;

namespace PROMetell
{
    /// <summary>
    /// Логика взаимодействия для JobCardFullInfoWindow.xaml
    /// </summary>
    public partial class JobCardFullInfoWindow : Window
    {
        JobCard currentJobCard;
        RouteSheet currentRouteSheet = new RouteSheet();
        public int jobCardId;
        public string productNum;
        public string productName;
        public string orderNum;
        public int areaId;
        public int workshopId;
        public string jobCardDateTime;
        public string jobCardMaster;
        public User loginUser;
        public int currentJobCardId;
        public JobCardFullInfoWindow(JobCard jobCard, User user)
        {
            InitializeComponent();
            currentJobCard = jobCard;
            currentJobCardId = currentJobCard.JobCardId;
            jobCardId = currentJobCardId;
            loginUser = user;
            JobCardFullInfoListView.ItemsSource = DB.DB.entities.JobCardTablePart.Where(c => c.JobCardId == currentJobCardId).ToList();
            //поиск номера наряда и вывод его на экран
            JobCardIdLabel.Content = currentJobCardId;
            //поиск номера заказа и вывод его на экран
            var currentJobCardProductNum = currentJobCard.ProductNum;
            productNum = currentJobCardProductNum;
            currentRouteSheet.ProductNum = currentJobCardProductNum;
            var currentRouteSheetOrderNum = DB.DB.entities.RouteSheet.FirstOrDefault(c => c.ProductNum == currentRouteSheet.ProductNum);
            if (currentRouteSheetOrderNum != null)
            {
                currentRouteSheet.OrderNum = currentRouteSheetOrderNum.OrderNum;
                OrderNumLabel.Content = Convert.ToString(currentRouteSheet.OrderNum);
                orderNum = Convert.ToString(currentRouteSheet.OrderNum);
            }
            else
            {
                OrderNumLabel.Content = "Нет";

            }
            //поиск номера цеха и вывод его на экран
            var currentWorkplace = DB.DB.entities.Workplace.FirstOrDefault(c => c.WorkplaceId == currentJobCard.WorkplaceId);
            var currentArea = currentWorkplace.AreaId;
            areaId = Convert.ToInt32(currentArea);
            var currentWorkshop = currentWorkplace.WorkshopId;
            workshopId = Convert.ToInt32(currentWorkshop);
            WorkShopIdLabel.Content = Convert.ToString(currentWorkshop);
            AreaIdLabel.Content = Convert.ToString(currentArea);
            //поиск даты и мастера
            JobCardDateLabel.Content = Convert.ToString(currentJobCard.JobCardDate);
            jobCardDateTime = Convert.ToString(currentJobCard.JobCardDate);
            if (currentJobCard.JobCardMaster != null)
            {
                JobCardMasterLabel.Content = Convert.ToString(currentJobCard.JobCardMaster);
                jobCardMaster = currentJobCard.JobCardMaster;
            }
            else
            {
                JobCardMasterLabel.Content = "Нет мастера";
                jobCardMaster = Convert.ToString(JobCardMasterLabel.Content);
            }
            //поиск кода детали и её наменования и вывод на экран
            ProductNumLabel.Content = Convert.ToString(currentJobCard.Product.ProductNum);
            productName = Convert.ToString(currentJobCard.Product.ProductName);
            ProductNameLabel.Content = Convert.ToString(currentJobCard.Product.ProductName);
            if (JobCardFullInfoListView.HasItems == false)
            {
                NoListLabel.Visibility = Visibility.Visible;
            }

        }
        JobCardTablePart currentJobCardTablePart;
        private void JobCardFullInfoListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            currentJobCardTablePart = (JobCardTablePart)JobCardFullInfoListView.SelectedItem;
        }
        private void AddJobCardTablePartRightClick_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            mainWindow.MainFrame.NavigationService.Navigate(new AddEditJobCardTablePartPage(currentJobCard, loginUser));
        }
        private void EditJobCardTablePartRightClick_Click(object sender, RoutedEventArgs e)
        {
            if (currentJobCardTablePart == null)
            {
                MessageBox.Show("Произошла ошибка. Пожалуйста, выберите запись, которую вы хотите изменить.", "Операция прервана", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
            else
            {
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
                mainWindow.MainFrame.NavigationService.Navigate(new AddEditJobCardTablePartPage(currentJobCard, currentJobCardTablePart, loginUser));
            }
        }
        private void DeleteJobCardTablePartRightClick_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (currentJobCardTablePart == null)
                {
                    MessageBox.Show("Произошла ошибка. Пожалуйста, выберите запись, которую вы хотите удалить.", "Ошибка удаления записи", MessageBoxButton.OK, MessageBoxImage.Stop);
                }
                else if (MessageBox.Show("Вы уверены, что хотите удалить запись?", "Удаление операции", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    try
                    {
                        JobCardTablePart jobCardTablePart = JobCardFullInfoListView.SelectedItem as JobCardTablePart;
                        DB.DB.entities.JobCardTablePart.Remove(jobCardTablePart);
                        DB.DB.entities.SaveChanges();
                        MessageBox.Show("Запись успешно удалена.", "Запись удалена", MessageBoxButton.OK, MessageBoxImage.Information);
                        JobCardFullInfoListView.ItemsSource = DB.DB.entities.JobCardTablePart.Where(c => c.JobCardId == currentJobCardId).ToList();
                    }
                    catch
                    {
                        MessageBox.Show("Произошла ошибка. Пожалуйста, повторите попытку позже.", "Неизвестная ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            catch
            {
                MessageBox.Show("Произошла неизвестная ошибка. Пожалуйста, повторите попытку позднее.", "Неизвестная ошибка", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
            if (JobCardFullInfoListView.HasItems == false)
            {
                NoListLabel.Visibility = Visibility.Visible;
            }
        }
        private void ReplaceKeywordWithValue(DocX document, string keyword, string value)
        {
            foreach (var paragraph in document.Paragraphs)
            {
                if (paragraph.Text.Contains(keyword))
                {
                    paragraph.ReplaceText(keyword, value);
                }
            }
        }
        private void AddItemToTable(int number, Xceed.Document.NET.Table table, Row rowPatternHigh, Row rowPatternLow, JobCardTablePart jobCardTablePart)
        {
            //заполнение табличной части документа
            var newItemHigh = table.InsertRow(rowPatternHigh, table.RowCount - 1);
            newItemHigh.ReplaceText(new StringReplaceTextOptions() { SearchValue = "%NUMBER%", NewValue = number.ToString() });
            var workerLastName = jobCardTablePart.Worker.WorkerLastName;
            var workerFirstName = jobCardTablePart.Worker.WorkerName.Substring(0,1);
            var workerPatronymic = jobCardTablePart.Worker.WorkerPatronymic.Substring(0, 1);
            var routeSheetCount = Convert.ToString(currentRouteSheet.WorkpieceCount);
            newItemHigh.ReplaceText(new StringReplaceTextOptions() { SearchValue = "%FIO%", NewValue = workerLastName + " " + workerFirstName + ". " + workerPatronymic + "." });
            newItemHigh.ReplaceText(new StringReplaceTextOptions() { SearchValue = "%READY%", NewValue = routeSheetCount });
            newItemHigh.ReplaceText(new StringReplaceTextOptions() { SearchValue = "%CODE%", NewValue = jobCardTablePart.WorkerPersonnelNum });
            var newItemLow = table.InsertRow(rowPatternLow, table.RowCount - 1);
            newItemLow.ReplaceText(new StringReplaceTextOptions() { SearchValue = "%NAME%", NewValue = jobCardTablePart.Operation.OperationName });
        }
        private void PrintButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (currentJobCard != null)
                {
                    using (var templateDoc = DocX.Load(@"C:\Users\semyo\Desktop\PROMetell\PROMetell\Job_card_example.docx"))
                    {
                        //заполнение шапки документа
                        string workShopNum = workshopId.ToString();
                        string areaNum = areaId.ToString();
                        string jobCardNum = jobCardId.ToString();
                        string detailNum = productNum.ToString();
                        string detailName = productName.ToString();
                        string orderId = orderNum.ToString();
                        string dateJobCard = jobCardDateTime.ToString();
                        ReplaceKeywordWithValue(templateDoc, "{1}", dateJobCard);
                        ReplaceKeywordWithValue(templateDoc, "{2}", workShopNum);
                        ReplaceKeywordWithValue(templateDoc, "{3}", areaNum);
                        ReplaceKeywordWithValue(templateDoc, "{4}", jobCardMaster);
                        ReplaceKeywordWithValue(templateDoc, "{5}", jobCardNum);
                        ReplaceKeywordWithValue(templateDoc, "{6}", orderId);
                        ReplaceKeywordWithValue(templateDoc, "{7}", detailNum);
                        ReplaceKeywordWithValue(templateDoc, "{8}", detailName);
                        ReplaceKeywordWithValue(templateDoc, "{9}", loginUser.Worker.WorkerLastName);
                        ReplaceKeywordWithValue(templateDoc, "{10}", loginUser.Worker.WorkerName);
                        ReplaceKeywordWithValue(templateDoc, "{11}", loginUser.Worker.WorkerPatronymic);
                        var reportTable = templateDoc.Tables[1];
                        var rowPatternHigh = reportTable.Rows[2];
                        var rowPatternLow = reportTable.Rows[3];
                        int counter = 1;
                        var table_parts = DB.DB.entities.JobCardTablePart.Where(c => c.JobCardId == currentJobCard.JobCardId);
                        foreach (var item in table_parts)
                        {
                            AddItemToTable(counter, reportTable, rowPatternHigh, rowPatternLow, item);
                            counter++;
                        }
                        rowPatternHigh.Remove();
                        rowPatternLow.Remove();
                        templateDoc.SaveAs($@"{Environment.GetFolderPath(Environment.SpecialFolder.Desktop)}\Наряд No_{jobCardNum}");
                        MessageBox.Show("Наряд успешно сформирован. Вы можете найти его на рабочем столе.", "Формирование документа прошло успешно", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Произошла ошибка формирования наряда. Пожалуйста, повторите попытку позднее.", "Ошибка формирования наряда", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void ReloadButton_Click(object sender, RoutedEventArgs e)
        {
            JobCardFullInfoListView.ItemsSource = DB.DB.entities.JobCardTablePart.Where(c => c.JobCardId == currentJobCardId).ToList();
            if (JobCardFullInfoListView.HasItems == true)
            {
                NoListLabel.Visibility = Visibility.Collapsed;
            }
            else
            {
                NoListLabel.Visibility= Visibility.Visible;
            }
        }
    }
}
