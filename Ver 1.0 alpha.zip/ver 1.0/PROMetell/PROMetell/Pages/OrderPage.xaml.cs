﻿using PROMetell.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PROMetell.Pages
{
    /// <summary>
    /// Логика взаимодействия для OrderPage.xaml
    /// </summary>
    public partial class OrderPage : Page
    {
        User loginUser;
        public OrderPage(User user)
        {
            InitializeComponent();
            OrderListView.ItemsSource = DB.DB.entities.Order.ToList();
            loginUser = user;
        }
        public Order currentOrder;
        private void OrderListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            currentOrder = (Order)OrderListView.SelectedItem;
        }
        private void AddOrderClick_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddEditOrderPage(loginUser));
        }
        private void EditOrderRightClick_Click(object sender, RoutedEventArgs e)
        {
            if (currentOrder == null)
            {
                MessageBox.Show("Произошла ошибка. Пожалуйста, выберите запись, которую вы хотите изменить.", "Операция прервана", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
            else
            {
                NavigationService.Navigate(new AddEditOrderPage(loginUser, currentOrder));
            }
        }
        private void DeleteOrderRightClick_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (currentOrder == null)
                {
                    MessageBox.Show("Произошла ошибка. Пожалуйста, выберите запись, которую вы хотите удалить.", "Ошибка удаления записи", MessageBoxButton.OK, MessageBoxImage.Stop);
                }
                else if (MessageBox.Show("Вы уверены, что хотите удалить запись?", "Удаление заказа", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    try
                    {
                        Order order = OrderListView.SelectedItem as Order;
                        RouteSheet routeSheet = new RouteSheet();
                        routeSheet = DB.DB.entities.RouteSheet.FirstOrDefault(o => o.OrderNum == order.OrderNum);
                        if (routeSheet != null)
                        {
                            DB.DB.entities.OperationList.RemoveRange(routeSheet.OperationList);
                            DB.DB.entities.RouteSheet.RemoveRange(order.RouteSheet);
                        }
                        DB.DB.entities.Order.Remove(order);
                        DB.DB.entities.SaveChanges();
                        MessageBox.Show("Запись успешно удалена.", "Запись удалена", MessageBoxButton.OK, MessageBoxImage.Information);
                        OrderListView.ItemsSource = DB.DB.entities.Order.ToList();
                    }
                    catch
                    {
                        MessageBox.Show("Произошла ошибка. Пожалуйста, повторите попытку позже.", "Неизвестная ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            catch
            {
                MessageBox.Show("Произошла неизвестная ошибка. Пожалуйста, повторите попытку позднее.", "Неизвестная ошибка", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
        }
        private void SearchOrderTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                if (SearchOrderTextBox.Text != null && SearchOrderTextBox.Text != "" && SearchOrderTextBox.Text != " ")
                {
                    OrderListView.ItemsSource = DB.DB.entities.Order.Where(c => c.CustomerName.Contains(SearchOrderTextBox.Text) || c.OrderDesc.Contains(SearchOrderTextBox.Text) || c.OrderNum.Contains(SearchOrderTextBox.Text)).ToList();
                    if (OrderListView.HasItems == false)
                    {
                        MessageBox.Show("Не найдено ни одной записи.", "Запись отсутствует", MessageBoxButton.OK, MessageBoxImage.None);
                        SearchOrderTextBox.Text = string.Empty;
                        OrderListView.ItemsSource = DB.DB.entities.Order.ToList();
                    }
                }
                else
                {
                    OrderListView.ItemsSource = DB.DB.entities.Order.ToList();
                }
            }
            catch (Exception error)
            {
                MessageBox.Show("Произошла ошибка поиска записей. Пожалуйста, повторите попытку позднее.", "Ошибка поиска данных", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
        }
        private void ProductPageButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ProductPage(loginUser));
        }

        private void WorkerPageButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new WorkerPage(loginUser));
        }

        private void JobCardPageButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new JobCardPage(loginUser));
        }
        private void GoBackButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (loginUser.RoleId == 2)
                {
                    NavigationService.Navigate(new SettingsPage(loginUser));
                }
                else if (MessageBox.Show("Вы уверены, что хотите выйти из аккаунта?", "Выход", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    NavigationService.Navigate(new AuthPage());
                }
            }
            catch
            {
                MessageBox.Show("Произошла неизвестная ошибка. Пожалуйста, повторите попытку позднее.", "Неизвестная ошибка", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
        }
    }
}
