﻿using PROMetell.DB;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PROMetell.Pages
{
    /// <summary>
    /// Логика взаимодействия для WorkerPage.xaml
    /// </summary>
    public partial class WorkerPage : Page
    {
        User currentUser;
        public WorkerPage(User user)
        {
            InitializeComponent();
            currentUser = user;
            WorkerListView.ItemsSource = DB.DB.entities.Worker.ToList();
            BrigadeListView.ItemsSource = DB.DB.entities.Brigade.ToList();
            WorkerPositionListView.ItemsSource = DB.DB.entities.WorkerPosition.ToList();
            RateListView.ItemsSource = DB.DB.entities.Rate.ToList();
        }
        private void StatisticRightClick_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new StatisticPage(currentWorker, currentUser));
        }
        //worker table
        public Worker currentWorker;
        private void WorkerListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            currentWorker = (Worker)WorkerListView.SelectedItem;
        }
        //right click abilities
        private void AddWorkerRightClick_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddEditWorkerPage(currentUser));
        }
        private void EditWorkerRightClick_Click(object sender, RoutedEventArgs e)
        {
            if (currentWorker != null)
            {
                NavigationService.Navigate(new AddEditWorkerPage(currentWorker, currentUser));
            }
            else
            {
                MessageBox.Show("Произошла ошибка. Пожалуйста, выберите запись перед тем, как приступить к редактированию.", "Ошибка редактирования записи", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void DeleteWorkerRightClick_Click(object sender, RoutedEventArgs e)
        {
            if (currentWorker == null)
            {
                MessageBox.Show("Произошла ошибка. Пожалуйста, выберите запись, которую вы хотите удалить.", "Ошибка удаления записи", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
            else if (MessageBox.Show("Вы уверены, что хотите удалить запись?", "Удаление заказа", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    Worker worker = WorkerListView.SelectedItem as Worker;
                    DB.DB.entities.JobCardTablePart.RemoveRange(worker.JobCardTablePart);
                    DB.DB.entities.User.RemoveRange(worker.User);
                    DB.DB.entities.Worker.Remove(worker);
                    DB.DB.entities.SaveChanges();
                    MessageBox.Show("Запись успешно удалена.", "Запись удалена", MessageBoxButton.OK, MessageBoxImage.Information);
                    WorkerListView.ItemsSource = DB.DB.entities.Worker.ToList();
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка. Пожалуйста, повторите попытку позже.", "Неизвестная ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {

            try
            {
                if (SearchBox.Text != null && SearchBox.Text != "" && SearchBox.Text != " ")
                {
                    if (SearchBox.Text != null && SearchBox.Text != "" && SearchBox.Text != " ")
                    {
                        WorkerListView.ItemsSource = DB.DB.entities.Worker.Where(c => c.WorkerLastName.Contains(SearchBox.Text) || c.WorkerName.Contains(SearchBox.Text)).ToList();
                        if (WorkerListView.HasItems == false)
                        {
                            MessageBox.Show("Не найдено ни одной записи.", "Запись отсутствует", MessageBoxButton.OK, MessageBoxImage.None);
                            SearchBox.Text = string.Empty;
                            WorkerListView.ItemsSource = DB.DB.entities.Worker.ToList();
                        }
                    }
                    else
                    {
                        WorkerListView.ItemsSource = DB.DB.entities.Worker.ToList();
                    }

                }
                else
                {
                    WorkerListView.ItemsSource = DB.DB.entities.Worker.ToList();
                }
            }
            catch (Exception error)
            {
                MessageBox.Show("Произошла ошибка поиска записей. Пожалуйста, повторите попытку позднее.", "Ошибка поиска данных", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
        }
        //brigade table
        public Brigade currentBrigade;
        private void BrigadeListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            currentBrigade = (Brigade)BrigadeListView.SelectedItem;
        }
        //right click abilities
        private void AddBrigadeRightClick_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddEditBrigadePage(currentUser));
        }

        private void EditBrigadeRightClick_Click(object sender, RoutedEventArgs e)
        {
            if (currentBrigade != null)
            {
                NavigationService.Navigate(new AddEditBrigadePage(currentBrigade, currentUser));
            }
            else
            {
                MessageBox.Show("Произошла ошибка. Пожалуйста, выберите запись перед тем, как приступить к редактированию.", "Ошибка редактирования записи", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void DeleteBrigadeRightClick_Click(object sender, RoutedEventArgs e)
        {
            if (currentBrigade == null)
            {
                MessageBox.Show("Произошла ошибка. Пожалуйста, выберите запись, которую вы хотите удалить.", "Ошибка удаления записи", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
            else if (MessageBox.Show("Вы уверены, что хотите удалить запись?", "Удаление заказа", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    Brigade brigade = BrigadeListView.SelectedItem as Brigade;
                    DB.DB.entities.Worker.RemoveRange(brigade.Worker);
                    DB.DB.entities.Brigade.Remove(brigade);
                    DB.DB.entities.SaveChanges();
                    MessageBox.Show("Запись успешно удалена.", "Запись удалена", MessageBoxButton.OK, MessageBoxImage.Information);
                    BrigadeListView.ItemsSource = DB.DB.entities.Brigade.ToList();
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка. Пожалуйста, повторите попытку позже.", "Неизвестная ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
        //workerposition table
        public WorkerPosition currentWorkerPosition;
        private void WorkerPositionListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            currentWorkerPosition = (WorkerPosition)WorkerPositionListView.SelectedItem;
        }
        private void AddWorkerPositionRightClick_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddEditWorkerPositionPage(currentUser));
        }
        private void EditWorkerPositionRightClick_Click(object sender, RoutedEventArgs e)
        {
            if (currentWorkerPosition != null)
            {
                NavigationService.Navigate(new AddEditWorkerPositionPage(currentWorkerPosition, currentUser));
            }
            else
            {
                MessageBox.Show("Произошла ошибка. Пожалуйста, выберите запись перед тем, как приступить к редактированию.", "Ошибка редактирования записи", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void DeleteWorkerPositionRightClick_Click(object sender, RoutedEventArgs e)
        {
            if (currentWorkerPosition == null)
            {
                MessageBox.Show("Произошла ошибка. Пожалуйста, выберите запись, которую вы хотите удалить.", "Ошибка удаления записи", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
            else if (MessageBox.Show("Вы уверены, что хотите удалить запись?", "Удаление заказа", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    WorkerPosition workerPosition = WorkerPositionListView.SelectedItem as WorkerPosition;
                    DB.DB.entities.Worker.RemoveRange(workerPosition.Worker);
                    DB.DB.entities.WorkerPosition.Remove(workerPosition);
                    DB.DB.entities.SaveChanges();
                    MessageBox.Show("Запись успешно удалена.", "Запись удалена", MessageBoxButton.OK, MessageBoxImage.Information);
                    WorkerPositionListView.ItemsSource = DB.DB.entities.WorkerPosition.ToList();
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка. Пожалуйста, повторите попытку позже.", "Неизвестная ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
        //rate table
        public Rate currentRate;
        private void RateListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            currentRate = (Rate)RateListView.SelectedItem;
        }
        private void AddRateRightClick_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddEditRatePage(currentUser));
        }
        private void EditRateRightClick_Click(object sender, RoutedEventArgs e)
        {
            if (currentRate != null)
            {
                NavigationService.Navigate(new AddEditRatePage(currentRate, currentUser));
            }
            else
            {
                MessageBox.Show("Произошла ошибка. Пожалуйста, выберите запись перед тем, как приступить к редактированию.", "Ошибка редактирования записи", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void DeleteRateRightClick_Click(object sender, RoutedEventArgs e)
        {
            if (currentRate == null)
            {
                MessageBox.Show("Произошла ошибка. Пожалуйста, выберите запись, которую вы хотите удалить.", "Ошибка удаления записи", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
            else if (MessageBox.Show("Вы уверены, что хотите удалить запись?", "Удаление заказа", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    Rate rate = RateListView.SelectedItem as Rate;
                    DB.DB.entities.Worker.RemoveRange(rate.Worker);
                    DB.DB.entities.Rate.Remove(rate);
                    DB.DB.entities.SaveChanges();
                    MessageBox.Show("Запись успешно удалена.", "Запись удалена", MessageBoxButton.OK, MessageBoxImage.Information);
                    RateListView.ItemsSource = DB.DB.entities.Rate.ToList();
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка. Пожалуйста, повторите попытку позже.", "Неизвестная ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
        private void OrderPageButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new OrderPage(currentUser));
        }
        private void ProductPageButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ProductPage(currentUser));
        }
        private void JobCardPageButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new JobCardPage(currentUser));
        }
        private void GoBackButton_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Вы уверены, что хотите выйти из аккаунта?", "Выход", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                NavigationService.Navigate(new AuthPage());
            }
        }
    }
}
