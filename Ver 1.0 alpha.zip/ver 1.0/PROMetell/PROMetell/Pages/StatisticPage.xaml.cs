﻿using LiveCharts.Wpf;
using LiveCharts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PROMetell.DB;

namespace PROMetell.Pages
{
    /// <summary>
    /// Логика взаимодействия для StatisticPage.xaml
    /// </summary>
    public partial class StatisticPage : Page
    {
        Worker worker;
        User user;
        public StatisticPage(Worker currentWorker, User currentUser)
        {
            InitializeComponent();
            worker = currentWorker;
            user = currentUser;
            ReloadPie();
        }

        private void ReloadButton_Click(object sender, RoutedEventArgs e)
        {
            ReloadPie();
        }

        void ReloadPie()
        {
            SeriesCollection AroundChartData = new SeriesCollection();
            List<JobCardTablePart> jobCardTablePartWorker = DB.DB.entities.JobCardTablePart.Where(c => c.WorkerPersonnelNum == worker.WorkerPersonnelNum).ToList();
            if (MinDatePicker.DisplayDate != DateTime.Now.Date)
            {
                jobCardTablePartWorker = jobCardTablePartWorker.Where(c => c.JobCard.JobCardDate >= MinDatePicker.DisplayDate && c.JobCard.JobCardDate <= MaxDatePicker.DisplayDate && c.WorkerPersonnelNum == worker.WorkerPersonnelNum).ToList();
            }
            foreach (var item in DB.DB.entities.Operation.ToList())
            {
                AroundChartData.Add(new PieSeries
                {
                    Values = new ChartValues<int> { jobCardTablePartWorker.Where(c => c.OperationId == item.OperationId).Count() },
                    Title = item.OperationName,
                });
            }
            pieDiagram.Series = AroundChartData;
        }

        private void GoBackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new WorkerPage(user));
        }
    }
}
