﻿using PROMetell.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PROMetell.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditOrderPage.xaml
    /// </summary>
    public partial class AddEditOrderPage : Page
    {
        Order editOrder;
        User user;
        bool isExist = true;
        public AddEditOrderPage(User loginUser)
        {
            InitializeComponent();
            user = loginUser;
            editOrder = new Order();
            isExist = false;
        }
        public AddEditOrderPage(User loginUser, Order currentOrder)
        {
            InitializeComponent();
            user = loginUser;
            editOrder = currentOrder;
            if (editOrder != null)
            {
                OrderNumTextBox.IsEnabled = false;
                OrderLabel.Content = "Изменение заказа";
                AddOrderButton.Content = "Изменить данные";
            }
        }
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            this.DataContext = editOrder;
        }

        private void AddOrderButton_Click(object sender, RoutedEventArgs e)
        {
            if (!isExist && OrderNumTextBox.Text != null && CustomerNameTextBox.Text != null)
            {
                try
                {
                    DB.DB.entities.Order.Add(editOrder);
                    DB.DB.entities.SaveChanges();
                    MessageBox.Show("Заказ успешно добавлен!", "Запись сохранена", MessageBoxButton.OK, MessageBoxImage.Information);
                    NavigationService.Navigate(new OrderPage(user));
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка, проверьте правильность заполнения полей.", "Запись не сохранена", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else if (OrderNumTextBox.Text != null && CustomerNameTextBox.Text != null)
            {
                try
                {
                    DB.DB.entities.SaveChanges();
                    MessageBox.Show("Информация о заказе успешно изменена!", "Запись сохранена", MessageBoxButton.OK, MessageBoxImage.Information);
                    NavigationService.Navigate(new OrderPage(user));
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка, проверьте правильность заполнения полей.", "Запись не сохранена", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Запись не была сохранена всвязи с отсутствием данных в полях. Проверьте, все ли поля заполнены, и попробуйте снова.", "Ошибка сохранения данных", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void GoBackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new OrderPage(user));
        }
    }
}
