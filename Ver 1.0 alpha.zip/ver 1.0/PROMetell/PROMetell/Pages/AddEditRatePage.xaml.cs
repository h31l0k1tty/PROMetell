﻿using PROMetell.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PROMetell.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditRatePage.xaml
    /// </summary>
    public partial class AddEditRatePage : Page
    {
        Rate editRate;
        public User user;
        bool isExist = true;
        public AddEditRatePage(User currentUser)
        {
            InitializeComponent();
            user = currentUser;
            isExist = false;
            editRate = new Rate();
        }
        public AddEditRatePage(Rate currentRate, User currentUser)
        {
            InitializeComponent();
            user = currentUser;
            editRate = currentRate;
            if (editRate != null)
            {
                RateNumTextBox.IsEnabled = false;
                RateLabel.Content = "Изменение разряда";
                AddRateButton.Content = "Изменить данные";
            }
        }
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            this.DataContext = editRate;
        }
        private void RateNumTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9.]+");
            e.Handled = regex.IsMatch(e.Text);
        }
        private void AddRateButton_Click(object sender, RoutedEventArgs e)
        {
            if (!isExist && RateNumTextBox != null && RateNameTextBox != null)
            {
                try
                {
                    DB.DB.entities.Rate.Add(editRate);
                    DB.DB.entities.SaveChanges();
                    MessageBox.Show("Разряд успешно добавлен!", "Запись сохранена", MessageBoxButton.OK, MessageBoxImage.Information);
                    NavigationService.Navigate(new OrderPage(user));
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка, проверьте правильность заполнения полей.", "Запись не сохранена", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else if (RateNumTextBox != null && RateNameTextBox != null)
            {
                try
                {
                    DB.DB.entities.SaveChanges();
                    MessageBox.Show("Информация о разряде успешно изменена!", "Запись сохранена", MessageBoxButton.OK, MessageBoxImage.Information);
                    NavigationService.Navigate(new OrderPage(user));
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка, проверьте правильность заполнения полей.", "Запись не сохранена", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Запись не была сохранена всвязи с отсутствием данных в полях. Проверьте, все ли поля заполнены, и попробуйте снова.", "Ошибка сохранения данных", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void GoBackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new WorkerPage(user));
        }
    }
}
