﻿using PROMetell.DB;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PROMetell.Pages
{
    /// <summary>
    /// Логика взаимодействия для ProductPage.xaml
    /// </summary>
    public partial class ProductPage : Page
    {
        User loginUser;
        public ProductPage(User user)
        {
            InitializeComponent();
            ProductListView.ItemsSource = DB.DB.entities.Product.ToList();
            loginUser = user;
        }
        Product currentProduct;
        private void ProductListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            currentProduct = (Product)ProductListView.SelectedItem;
        }
        private void AddProductRightClick_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddEditProductPage(loginUser));
        }

        private void EditProductRightClick_Click(object sender, RoutedEventArgs e)
        {
            if (currentProduct != null)
            {
                NavigationService.Navigate(new AddEditProductPage(loginUser, currentProduct));
            }
            else
            {
                MessageBox.Show("Произошла ошибка. Пожалуйста, выберите запись перед тем, как приступить к редактированию.", "Ошибка редактирования записи", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void DeleteProductRightClick_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (currentProduct == null)
                {
                    MessageBox.Show("Произошла ошибка. Пожалуйста, выберите запись, которую вы хотите удалить.", "Ошибка удаления записи", MessageBoxButton.OK, MessageBoxImage.Stop);
                }
                else if (MessageBox.Show("Вы уверены, что хотите удалить запись?", "Удаление заказа", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    try
                    {
                        Product product = ProductListView.SelectedItem as Product;
                        RouteSheet routeSheet = new RouteSheet();
                        routeSheet = DB.DB.entities.RouteSheet.FirstOrDefault(c => c.ProductNum == product.ProductNum);
                        if (routeSheet != null)
                        {
                            DB.DB.entities.RouteSheet.RemoveRange(product.RouteSheet);
                        }
                        JobCard jobCard = new JobCard();
                        jobCard = DB.DB.entities.JobCard.FirstOrDefault(c => c.ProductNum == product.ProductNum);
                        if (jobCard != null)
                        {
                            DB.DB.entities.JobCard.RemoveRange(product.JobCard);
                        }
                        DB.DB.entities.Product.Remove(product);
                        DB.DB.entities.SaveChanges();
                        MessageBox.Show("Запись успешно удалена.", "Запись удалена", MessageBoxButton.OK, MessageBoxImage.Information);
                        ProductListView.ItemsSource = DB.DB.entities.Product.ToList();
                    }
                    catch
                    {
                        MessageBox.Show("Произошла ошибка. Пожалуйста, повторите попытку позже.", "Неизвестная ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            catch
            {
                MessageBox.Show("Произошла неизвестная ошибка. Пожалуйста, повторите попытку позднее.", "Неизвестная ошибка", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
        }
        private void JobCardPageButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new JobCardPage(loginUser));
        }
        private void WorkerPageButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new WorkerPage(loginUser));
        }

        private void OrderPageButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new OrderPage(loginUser));
        }
        private void GoBackButton_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Вы уверены, что хотите выйти из аккаунта?", "Выход", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                NavigationService.Navigate(new AuthPage());
            }
        }
    }
}
