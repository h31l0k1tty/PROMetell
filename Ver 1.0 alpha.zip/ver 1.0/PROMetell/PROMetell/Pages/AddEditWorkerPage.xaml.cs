﻿using PROMetell.DB;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Xceed.Document.NET;

namespace PROMetell.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditWorkerPage.xaml
    /// </summary>
    public partial class AddEditWorkerPage : Page
    {
        Worker editWorker;
        bool isExist = true;
        User loginUser;
        public AddEditWorkerPage(User user)
        {
            InitializeComponent();
            isExist = false;
            BrigadeComboBox.ItemsSource = DB.DB.entities.Brigade.ToList();
            RateComboBox.ItemsSource = DB.DB.entities.Rate.ToList();
            WorkerPositionComboBox.ItemsSource = DB.DB.entities.WorkerPosition.ToList();
            editWorker = new Worker();
            loginUser = user;
        }

        public AddEditWorkerPage(Worker currentWorker, User user)
        {
            InitializeComponent();
            BrigadeComboBox.ItemsSource = DB.DB.entities.Brigade.ToList();
            RateComboBox.ItemsSource = DB.DB.entities.Rate.ToList();
            WorkerPositionComboBox.ItemsSource = DB.DB.entities.WorkerPosition.ToList();
            editWorker = currentWorker;
            loginUser = user;
            if (editWorker != null)
            {
                WorkerPersonnelNumTextBox.IsEnabled = false;
                WorkerLabel.Content = "Изменение работника";
                AddWorkerButton.Content = "Изменить данные";
            }
        }
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            this.DataContext = editWorker;
        }
        private void BrigadeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            editWorker.Brigade = (Brigade)BrigadeComboBox.SelectedItem;
        }

        private void WorkerPositionComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            editWorker.WorkerPosition = (WorkerPosition)WorkerPositionComboBox.SelectedItem;
        }

        private void RateComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            editWorker.Rate = (Rate)RateComboBox.SelectedItem;
        }

        private void AddWorkerButton_Click(object sender, RoutedEventArgs e)
        {
            if (!isExist && WorkerPersonnelNumTextBox != null && WorkerLastNameTextBox != null && WorkerNameTextBox != null && WorkerPositionComboBox.SelectedItem != null && BrigadeComboBox.SelectedItem != null && RateComboBox.SelectedItem != null)
            {
                try
                {
                    DB.DB.entities.Worker.Add(editWorker);
                    DB.DB.entities.SaveChanges();
                    MessageBox.Show("Работник успешно добавлен!", "Запись сохранена", MessageBoxButton.OK, MessageBoxImage.Information);
                    NavigationService.Navigate(new WorkerPage(loginUser));
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка, проверьте правильность заполнения полей.", "Запись не сохранена", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else if (WorkerPersonnelNumTextBox != null && WorkerLastNameTextBox != null && WorkerNameTextBox != null && WorkerPositionComboBox.SelectedItem != null && BrigadeComboBox.SelectedItem != null && RateComboBox.SelectedItem != null)
            {
                try
                {
                    DB.DB.entities.SaveChanges();
                    MessageBox.Show("Информация о работнике успешно изменена!", "Запись сохранена", MessageBoxButton.OK, MessageBoxImage.Information);
                    NavigationService.Navigate(new WorkerPage(loginUser));
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка, проверьте правильность заполнения полей.", "Запись не сохранена", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Запись не была сохранена всвязи с отсутствием данных в полях. Проверьте, все ли поля заполнены, и попробуйте снова.", "Ошибка сохранения данных", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void GoBackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new WorkerPage(loginUser));
        }
    }
}
