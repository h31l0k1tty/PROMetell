﻿using PROMetell.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PROMetell.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditRouteSheetPage.xaml
    /// </summary>
    public partial class AddEditRouteSheetPage : Page
    {
        private RouteSheet routeSheet;
        private User loginUser;
        bool isExist = true;
        public AddEditRouteSheetPage(User user)
        {
            InitializeComponent();
            isExist = false;
            loginUser = user;
            routeSheet = new RouteSheet();
            OrderComboBox.ItemsSource = DB.DB.entities.Order.ToList();
            ProductComboBox.ItemsSource = DB.DB.entities.Product.ToList();
            DatePicker currentDate = new DatePicker();
            currentDate.SelectedDate = DateTime.Today;
            CompletedDatePicker.SelectedDate = currentDate.SelectedDate;
        }

        public AddEditRouteSheetPage(RouteSheet currentRouteSheet, User user)
        {
            InitializeComponent();
            routeSheet = currentRouteSheet;
            loginUser = user;
            OrderComboBox.ItemsSource = DB.DB.entities.Order.ToList();
            ProductComboBox.ItemsSource = DB.DB.entities.Product.ToList();
            if (currentRouteSheet != null)
            {
                RouteSheetLabel.Content = "Изменение маршрутной карты";
                AddRouteSheetButton.Content = "Изменить данные";
                CompletedDatePicker.SelectedDate = routeSheet.CompletedDate;
            }
        }
        private void CompletedDatePicker_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9.]+");
            e.Handled = regex.IsMatch(e.Text);
        }
        private void CompletedProductCountTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9.]+");
            e.Handled = regex.IsMatch(e.Text);
        }
        private void AdjustmentProductCountTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9.]+");
            e.Handled = regex.IsMatch(e.Text);
        }
        private void WorkpieceCountTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9.]+");
            e.Handled = regex.IsMatch(e.Text);
        }
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            this.DataContext = routeSheet;
        }
        private void ProductComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            routeSheet.Product = (Product)ProductComboBox.SelectedItem;
        }
        private void OrderComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            routeSheet.Order = (Order)OrderComboBox.SelectedItem;
        }

        private void AddRouteSheetButton_Click(object sender, RoutedEventArgs e)
        {
            if (!isExist && RouteSheetNumTextBox.Text != null && OrderComboBox.SelectedItem != null && ProductComboBox.SelectedItem != null)
            {
                try
                {
                    routeSheet.CompletedDate = CompletedDatePicker.SelectedDate.Value.Date;
                    DB.DB.entities.RouteSheet.Add(routeSheet);
                    DB.DB.entities.SaveChanges();
                    MessageBox.Show("Маршрутная карта добавлена!", "Запись сохранена", MessageBoxButton.OK, MessageBoxImage.Information);
                    NavigationService.Navigate(new JobCardPage(loginUser));
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка, проверьте правильность заполнения полей.", "Запись не сохранена", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else if (RouteSheetNumTextBox.Text != null && OrderComboBox.SelectedItem != null && ProductComboBox.SelectedItem != null)
            {
                try
                {
                    routeSheet.CompletedDate = CompletedDatePicker.SelectedDate.Value.Date;
                    DB.DB.entities.SaveChanges();
                    MessageBox.Show("Информация о маршрутной карте успешно изменена!", "Запись сохранена", MessageBoxButton.OK, MessageBoxImage.Information);
                    NavigationService.Navigate(new JobCardPage(loginUser));
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка, проверьте правильность заполнения полей.", "Запись не сохранена", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Запись не была сохранена всвязи с отсутствием данных в полях. Проверьте, все ли поля заполнены, и попробуйте снова.", "Ошибка сохранения данных", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void GoBackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new JobCardPage(loginUser));
        }
    }
}
