﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROMetell.DB
{
    public static class UserClass
    {
        public static User user = new User();
    }
}
