﻿using PROMetell.DB;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PROMetell.Pages
{
    /// <summary>
    /// Логика взаимодействия для SettingsPage.xaml
    /// </summary>
    public partial class SettingsPage : Page
    {
        public User authUser;
        public SettingsPage(User loginUser)
        {
            InitializeComponent();
            authUser = loginUser;
            string userLastName = authUser.Worker.WorkerLastName;
            LastNameLabel.Content = userLastName;
            string userName = authUser.Worker.WorkerName;
            NameLabel.Content = userName;
            string userPatronymic = authUser.Worker.WorkerPatronymic;
            PatronymicLabel.Content = userPatronymic;
        }

        private void RegistrationButton_Click(object sender, RoutedEventArgs e)
        {
            RegistrationWindow registrationWindow = new RegistrationWindow(authUser);
            registrationWindow.Show();
        }

        private void JobCardButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new JobCardPage(authUser));
        }

        private void RouteSheetButton_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
