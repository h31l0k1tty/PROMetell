﻿using PROMetell.DB;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Xceed.Document.NET;
using Xceed.Words.NET;

namespace PROMetell.Pages
{
    /// <summary>
    /// Логика взаимодействия для JobCardPage.xaml
    /// </summary>
    public partial class JobCardPage : Page
    {
        User user;
        public JobCardPage(User loginUser)
        {
            InitializeComponent();
            JobCardListView.ItemsSource = DB.DB.entities.JobCard.ToList();
            OperationListView.ItemsSource = DB.DB.entities.Operation.ToList();
            user = loginUser;
            if (user.RoleId == 7)
            {
                ProductPageButton.IsEnabled = false;
                WorkerPageButton.IsEnabled = false;
                OrderPageButton.IsEnabled = false;
                AddJobCardButton.IsEnabled = false;
                AddOperationButton.IsEnabled = false;
                EditOperationButton.IsEnabled = false;
                EditJobCardButton.IsEnabled = false;
            }
        }
        private void ReplaceKeywordWithValue(DocX document, string keyword, string value)
        {
            foreach (var paragraph in document.Paragraphs)
            {
                if (paragraph.Text.Contains(keyword))
                {
                    paragraph.ReplaceText(keyword, value);
                }
            }
        }
        private static void AddItemToTable(int number, Xceed.Document.NET.Table table, Row rowPatternHigh, Row rowPatternLow, JobCardTablePart job_Card_Table_Part)
        {
            var newItemHigh = table.InsertRow(rowPatternHigh, table.RowCount - 1);
            newItemHigh.ReplaceText(new StringReplaceTextOptions() { SearchValue = "%NUMBER%", NewValue = number.ToString() });
            newItemHigh.ReplaceText(new StringReplaceTextOptions() { SearchValue = "%FIO%", NewValue = job_Card_Table_Part.Worker.WorkerLastName });
            newItemHigh.ReplaceText(new StringReplaceTextOptions() { SearchValue = "%CODE%", NewValue = job_Card_Table_Part.WorkerPersonnelNum });
            var newItemLow = table.InsertRow(rowPatternLow, table.RowCount - 1);
            newItemLow.ReplaceText(new StringReplaceTextOptions() { SearchValue = "%NAME%", NewValue = job_Card_Table_Part.Operation.OperationName });
        }
        private void PrintButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (JobCardListView.SelectedItems != null && JobCardListView.SelectedItem != null)
                {
                    using (var templateDoc = DocX.Load(@"C:\Users\semyo\Desktop\PROMetellDoc\PROMetellDoc\Properties\Job_card_example.docx"))
                    {
                        var workplace = DB.DB.entities.Workplace.First(c => c.WorkplaceId == ((JobCard)JobCardListView.SelectedItem).WorkplaceId);
                        string wp_Num = workplace.WorkshopId.ToString();
                        string area_Num = workplace.AreaId.ToString();
                        string jc_Num = ((JobCard)JobCardListView.SelectedItem).JobCardId.ToString();
                        ReplaceKeywordWithValue(templateDoc, "{2}", wp_Num);
                        ReplaceKeywordWithValue(templateDoc, "{3}", area_Num);
                        ReplaceKeywordWithValue(templateDoc, "{5}", jc_Num);
                        var reportTable = templateDoc.Tables[1];
                        var rowPatternHigh = reportTable.Rows[2];
                        var rowPatternLow = reportTable.Rows[3];
                        int counter = 1;
                        var table_parts = DB.DB.entities.JobCardTablePart.Where(c => c.JobCardId == ((JobCard)JobCardListView.SelectedItem).JobCardId);
                        foreach (var item in table_parts)
                        {
                            AddItemToTable(counter, reportTable, rowPatternHigh, rowPatternLow, item);
                            counter++;
                        }
                        rowPatternHigh.Remove();
                        rowPatternLow.Remove();
                        templateDoc.SaveAs($@"{Environment.GetFolderPath(Environment.SpecialFolder.Desktop)}\Наряд No_{jc_Num}");
                        MessageBox.Show("Наряд успешно сформирован. Вы можете найти его на рабочем столе.", "Формирование документа прошло успешно", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при создании документа: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void GoBackButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (user.RoleId == 2)
                {
                    NavigationService.Navigate(new SettingsPage(user));
                }
                else if (MessageBox.Show("Вы уверены, что хотите выйти из аккаунта?", "Выход", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    NavigationService.Navigate(new AuthPage());
                }
            }
            catch
            {
                MessageBox.Show("Произошла неизвестная ошибка. Пожалуйста, повторите попытку позднее.", "Неизвестная ошибка", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
        }
        public JobCard currentJobCard;
        private void JobCardListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            currentJobCard = (JobCard)JobCardListView.SelectedItem;
        }
        public Operation currentOperation;
        private void OperationListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            currentOperation = (DB.Operation)OperationListView.SelectedItem;
        }

        private void AddJobCardButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void EditJobCardButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void DeleteJobCardButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (currentJobCard == null)
                {
                    MessageBox.Show("Произошла ошибка. Пожалуйста, выберите запись, которую вы хотите удалить.", "Ошибка удаления записи", MessageBoxButton.OK, MessageBoxImage.Stop);
                }
                else if (MessageBox.Show("Вы уверены, что хотите удалить запись?", "Удаление заказа", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    try
                    {
                        JobCard jc = JobCardListView.SelectedItem as JobCard;
                        DB.DB.entities.JobCardTablePart.RemoveRange(jc.JobCardTablePart);
                        DB.DB.entities.JobCard.Remove(jc);
                        DB.DB.entities.SaveChanges();
                        MessageBox.Show("Запись успешно удалена.", "Запись удалена", MessageBoxButton.OK, MessageBoxImage.Information);
                        JobCardListView.ItemsSource = DB.DB.entities.JobCard.ToList();
                    }
                    catch
                    {
                        MessageBox.Show("Произошла ошибка. Пожалуйста, повторите попытку позже.", "Неизвестная ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            catch
            {
                MessageBox.Show("Произошла неизвестная ошибка. Пожалуйста, повторите попытку позднее.", "Неизвестная ошибка", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
        }

        private void AddOperationButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void EditOperationButton_Click(object sender, RoutedEventArgs e)
        {

        }
        private void PrintDeliveryStickerButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void OrderPageButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ProductPageButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void WorkerPageButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void JobCardPageButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void FullInfoRight_Click(object sender, RoutedEventArgs e)
        {
            JobCardFullInfoWindow jobCardFullInfoWindow = new JobCardFullInfoWindow();
            jobCardFullInfoWindow.Show();
        }
    }
}
