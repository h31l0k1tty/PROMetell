﻿using PROMetell.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PROMetell
{
    /// <summary>
    /// Логика взаимодействия для RegistrationWindow.xaml
    /// </summary>
    public partial class RegistrationWindow : Window
    {
        User authUser;
        User newUser = new User();
        Worker newWorker = new Worker();
        public RegistrationWindow(User authUser)
        {
            InitializeComponent();
            this.authUser = authUser;
            BrigadeComboBox.ItemsSource = DB.DB.entities.Brigade.ToList();
            WorkerPositionComboBox.ItemsSource = DB.DB.entities.WorkerPosition.ToList();
            RateComboBox.ItemsSource = DB.DB.entities.Rate.ToList();
            RoleComboBox.ItemsSource = DB.DB.entities.Role.ToList();
        }
 
        private void WorkerPersonnelNumTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void BrigadeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            newWorker.Brigade = (Brigade)BrigadeComboBox.SelectedItem;       
        }

        private void WorkerPositionComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            newWorker.WorkerPosition = (WorkerPosition)WorkerPositionComboBox.SelectedItem;
        }

        private void RateComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            newWorker.Rate = (Rate)RateComboBox.SelectedItem;
        }

        private void RoleComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            newUser.Role = (Role)RoleComboBox.SelectedItem;
        }

        private void AddNewUserButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (WorkerPersonnelNumTextBox.Text != null && WorkerLastNameTextBox.Text != null && WorkerNameTextBox.Text != null && UserLoginTextBox.Text != null && UserPasswordTextBox.Text != null)
                {
                    //adding new worker into a database
                    newWorker.WorkerPersonnelNum = WorkerPersonnelNumTextBox.Text;
                    newWorker.WorkerLastName = WorkerLastNameTextBox.Text;
                    newWorker.WorkerName = WorkerNameTextBox.Text;
                    newWorker.WorkerPatronymic = WorkerPatronymicTextBox.Text;
                    DB.DB.entities.Worker.Add(newWorker);
                    DB.DB.entities.SaveChanges();
                    if (newWorker.WorkerPersonnelNum != null)
                    {
                    //adding new user into a database
                    newUser.WorkerPersonnelNum = newWorker.WorkerPersonnelNum;
                    newUser.UserLogin = UserLoginTextBox.Text;
                    newUser.UserPassword = UserPasswordTextBox.Text;
                    DB.DB.entities.User.Add(newUser);
                    DB.DB.entities.SaveChanges();
                    newUser.UserLogin = UserLoginTextBox.Text;
                    newUser.UserPassword = UserPasswordTextBox.Text;
                    MessageBox.Show("Пользователь успешно добавлен!", "Запись сохранена", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Пользователь не добавлен! Проверьте, заполнены ли все поля.", "Запись не сохранена", MessageBoxButton.OK, MessageBoxImage.Information);

                }
            }
            catch
            {
                MessageBox.Show("Произошла неизвестная ошибка. Пожалуйста, повторите попытку позднее.", "Неизвестная ошибка", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void GoBackButton_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Вы уверены, что хотите отменить регистрацию? Несохранённые данные будут удалены.", "Отмена регистрации", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                this.Close();
            }
        }

    }
}
