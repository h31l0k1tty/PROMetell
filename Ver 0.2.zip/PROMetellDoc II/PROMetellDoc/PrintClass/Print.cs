﻿using PROMetellDoc.DataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROMetellDoc.PrintClass
{
    public class Print
    {
        public static void OutPut(Job_card card)
        {

        }
    }
}
