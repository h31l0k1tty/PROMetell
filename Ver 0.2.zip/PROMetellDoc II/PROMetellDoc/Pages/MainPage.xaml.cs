﻿using PROMetellDoc.DataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PROMetellDoc.Pages
{
    /// <summary>
    /// Логика взаимодействия для MainPage.xaml
    /// </summary>
    public partial class MainPage : Page
    {
        public MainPage()
        {
            InitializeComponent();
            WorkerListView.ItemsSource = DataBase.DB.entities.Worker.ToList();
            BrigadeListView.ItemsSource = DataBase.DB.entities.Brigade.ToList();
            WorkerPositionListView.ItemsSource = DataBase.DB.entities.Worker_position.ToList();
            RateListView.ItemsSource = DataBase.DB.entities.Rate.ToList();

        }
        private void OrderPageButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new OrderPage());
        }
        private void ProductPageButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ProductPage());
        }
        private void JobCardPageButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new JobCardPage());
        }
        private void GoBackButton_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Вы уверены, что хотите выйти из аккаунта?", "Выход", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                NavigationService.Navigate(new AuthPage());
            }
        }
        private void AddWorkerButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddEditWorkerPage());
        }

        public Worker CurrentWorker;

        private void WorkerListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            CurrentWorker = (DataBase.Worker)WorkerListView.SelectedItem;
        }

        private void EditWorkerButton_Click(object sender, RoutedEventArgs e)
        {
            if (CurrentWorker != null)
            {
                NavigationService.Navigate(new AddEditWorkerPage(CurrentWorker));
            }
            else
            {
                MessageBox.Show("Произошла ошибка. Пожалуйста, выберите запись перед тем, как приступить к редактированию.", "Ошибка редактирования записи", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void DeleteWorkerButton_Click(object sender, RoutedEventArgs e)
        {
            if (CurrentWorker == null)
            {
                MessageBox.Show("Произошла ошибка. Пожалуйста, выберите запись, которую вы хотите удалить.", "Ошибка удаления записи", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
            else if (MessageBox.Show("Вы уверены, что хотите удалить запись?", "Удаление заказа", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    DataBase.Worker worker = WorkerListView.SelectedItem as DataBase.Worker;
                    DB.entities.Job_card_table_part.RemoveRange(worker.Job_card_table_part);
                    DB.entities.User.RemoveRange(worker.User);
                    DB.entities.Worker.Remove(worker);
                    DB.entities.SaveChanges();
                    MessageBox.Show("Запись успешно удалена.", "Запись удалена", MessageBoxButton.OK, MessageBoxImage.Information);
                    WorkerListView.ItemsSource = DB.entities.Worker.ToList();
                }
                catch 
                {
                    MessageBox.Show("Произошла ошибка. Пожалуйста, повторите попытку позже.", "Неизвестная ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
        public Brigade CurrentBrigade;
        private void BrigadeListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            CurrentBrigade = (DataBase.Brigade)BrigadeListView.SelectedItem;
        }
        public Worker_position CurrentWP;
        private void WorkerPositionListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            CurrentWP = (DataBase.Worker_position)WorkerPositionListView.SelectedItem;
        }
        public Rate CurrentRate;
        private void RateListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            CurrentRate = (DataBase.Rate)RateListView.SelectedItem;
        }
        private void AddBrigadeButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddEditBrigadePage());
        }

        private void EditBrigadeButton_Click(object sender, RoutedEventArgs e)
        {
            if (CurrentBrigade != null)
            {
                NavigationService.Navigate(new AddEditBrigadePage(CurrentBrigade));
            }
            else
            {
                MessageBox.Show("Произошла ошибка. Пожалуйста, выберите запись перед тем, как приступить к редактированию.", "Ошибка редактирования записи", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddWPkButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddEditWPPage());
        }

        private void EditWPButton_Click(object sender, RoutedEventArgs e)
        {
            if (CurrentWP != null)
            {
                NavigationService.Navigate(new AddEditWPPage(CurrentWP));
            }
            else
            {
                MessageBox.Show("Произошла ошибка. Пожалуйста, выберите запись перед тем, как приступить к редактированию.", "Ошибка редактирования записи", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddRateButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddEditRatePage());
        }

        private void EditRateButton_Click(object sender, RoutedEventArgs e)
        {
            if (CurrentRate != null)
            {
                NavigationService.Navigate(new AddEditRatePage(CurrentRate));
            }
            else
            {
                MessageBox.Show("Произошла ошибка. Пожалуйста, выберите запись перед тем, как приступить к редактированию.", "Ошибка редактирования записи", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (SearchBox.Text != null && SearchBox.Text != "" && SearchBox.Text != " ")
            {
                WorkerListView.ItemsSource = DataBase.DB.entities.Worker.Where(c => c.Worker_lastname.Contains(SearchBox.Text) || c.Worker_name.Contains(SearchBox.Text)).ToList();
            }
            else
            {
                WorkerListView.ItemsSource = DataBase.DB.entities.Worker.ToList();
            }
        }

    }
}
