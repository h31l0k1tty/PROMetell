﻿using PROMetellDoc.DataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PROMetellDoc.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditWorkerPage.xaml
    /// </summary>
    public partial class AddEditWorkerPage : Page
    {
        Worker editWorker;
        bool isExist = true;
        public AddEditWorkerPage()
        {
            InitializeComponent();
            isExist = false;
            Brigade_ComboBox.ItemsSource = DB.entities.Brigade.ToList();
            Rate_ComboBox.ItemsSource= DB.entities.Rate.ToList();
            WP_ComboBox.ItemsSource = DB.entities.Worker_position.ToList();
            editWorker = new DataBase.Worker();
        }

        public AddEditWorkerPage(Worker worker)
        {
            InitializeComponent();
            Brigade_ComboBox.ItemsSource = DB.entities.Brigade.ToList();
            Rate_ComboBox.ItemsSource= DB.entities.Rate.ToList();
            WP_ComboBox.ItemsSource = DB.entities.Worker_position.ToList();
            editWorker = worker;
            if (editWorker != null)
            {
                Worker_personnel_num_TextBox.IsEnabled = false;
            }
        }

        private void GoBackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new MainPage());
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            this.DataContext = editWorker;
        }

        private void Brigade_ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            editWorker.Brigade = (DataBase.Brigade)Brigade_ComboBox.SelectedItem;
        }

        private void WP_ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            editWorker.Worker_position = (DataBase.Worker_position)WP_ComboBox.SelectedItem;
        }

        private void Rate_ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            editWorker.Rate = (DataBase.Rate)Rate_ComboBox.SelectedItem;
        }

        private void AddWorkerButton_Click(object sender, RoutedEventArgs e)
        {
            if (!isExist && Worker_personnel_num_TextBox != null && Worker_lastname_TextBox != null && Worker_name_TextBox != null && WP_ComboBox.SelectedItem != null && Brigade_ComboBox.SelectedItem != null && Rate_ComboBox.SelectedItem != null)
            {
                try
                {
                    DB.entities.Worker.Add(editWorker);
                    DB.entities.SaveChanges();
                    MessageBox.Show("Работник успешно добавлен!", "Запись сохранена", MessageBoxButton.OK, MessageBoxImage.Information);
                    NavigationService.Navigate(new MainPage());
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка, проверьте правильность заполнения полей.", "Запись не сохранена", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else if (Worker_personnel_num_TextBox != null && Worker_lastname_TextBox != null && Worker_name_TextBox != null && WP_ComboBox.SelectedItem != null && Brigade_ComboBox.SelectedItem != null && Rate_ComboBox.SelectedItem != null)
            {
                try
                {
                    DB.entities.SaveChanges();
                    MessageBox.Show("Информация о работнике успешно изменена!", "Запись сохранена", MessageBoxButton.OK, MessageBoxImage.Information);
                    NavigationService.Navigate(new MainPage());
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка, проверьте правильность заполнения полей.", "Запись не сохранена", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Запись не была сохранена всвязи с отсутствием данных в полях. Проверьте, все ли поля заполнены, и попробуйте снова.", "Ошибка сохранения данных", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
