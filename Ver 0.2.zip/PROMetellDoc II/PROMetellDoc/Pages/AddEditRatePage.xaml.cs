﻿using PROMetellDoc.DataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PROMetellDoc.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditRatePage.xaml
    /// </summary>
    public partial class AddEditRatePage : Page
    {
        Rate editRate;
        bool isExist = true;
        public AddEditRatePage()
        {
            InitializeComponent();
            isExist = false;
        }

        public AddEditRatePage(Rate rate)
        {
            InitializeComponent();
            editRate = rate;
            if (editRate != null) 
            {
                Rate_num_TextBox.IsEnabled = false;
            }
        }

        private void AddRateButton_Click(object sender, RoutedEventArgs e)
        {
            if (!isExist && Rate_num_TextBox != null && Rate_name_TextBox != null)
            {
                try
                {
                    DB.entities.Rate.Add(editRate);
                    DB.entities.SaveChanges();
                    MessageBox.Show("Разряд успешно добавлен!", "Запись сохранена", MessageBoxButton.OK, MessageBoxImage.Information);
                    NavigationService.Navigate(new OrderPage());
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка, проверьте правильность заполнения полей.", "Запись не сохранена", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else if (Rate_num_TextBox != null && Rate_name_TextBox != null)
            {
                try
                {
                    DB.entities.SaveChanges();
                    MessageBox.Show("Информация о разряде успешно изменена!", "Запись сохранена", MessageBoxButton.OK, MessageBoxImage.Information);
                    NavigationService.Navigate(new OrderPage());
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка, проверьте правильность заполнения полей.", "Запись не сохранена", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Запись не была сохранена всвязи с отсутствием данных в полях. Проверьте, все ли поля заполнены, и попробуйте снова.", "Ошибка сохранения данных", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void GoBackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new MainPage());
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            this.DataContext = editRate;
        }
    }
}
