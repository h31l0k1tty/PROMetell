﻿using PROMetellDoc.DataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PROMetellDoc.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditProductPage.xaml
    /// </summary>
    public partial class AddEditProductPage : Page
    {
        Product editProduct;
        bool isExist = true;
        public AddEditProductPage()
        {
            InitializeComponent();
            isExist = false;
        }
        public AddEditProductPage(Product product)
        {
            InitializeComponent();
            editProduct = product;
            if (editProduct != null)
            {
                Product_code_TextBox.IsEnabled = false;
            }
        }

        private void GoBackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ProductPage());
        }

        private void AddProductButton_Click(object sender, RoutedEventArgs e)
        {
            if (!isExist && Product_code_TextBox != null && Product_name_TextBox != null)
            {
                try
                {
                    DB.entities.Product.Add(editProduct);
                    DB.entities.SaveChanges();
                    MessageBox.Show("Изделие успешно добавлено!", "Запись сохранена", MessageBoxButton.OK, MessageBoxImage.Information);
                    NavigationService.Navigate(new ProductPage());
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка, проверьте правильность заполнения полей.", "Запись не сохранена", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else if (Product_code_TextBox != null && Product_name_TextBox != null)
            {
                try
                {
                    DB.entities.SaveChanges();
                    MessageBox.Show("Информация об изделии успешно изменена!", "Запись сохранена", MessageBoxButton.OK, MessageBoxImage.Information);
                    NavigationService.Navigate(new ProductPage());
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка, проверьте правильность заполнения полей.", "Запись не сохранена", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Запись не была сохранена всвязи с отсутствием данных в полях. Проверьте, все ли поля заполнены, и попробуйте снова.", "Ошибка сохранения данных", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            this.DataContext = editProduct;
        }
    }
}
