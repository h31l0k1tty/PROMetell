﻿using PROMetellDoc.DataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Xceed.Document.NET;
using Xceed.Words.NET;

namespace PROMetellDoc.Pages
{
    /// <summary>
    /// Логика взаимодействия для JobCardPage.xaml
    /// </summary>
    public partial class JobCardPage : Page
    {
        User user;
        public JobCardPage()
        {
            InitializeComponent();
            JobCardListView.ItemsSource = DB.entities.Job_card.ToList();
            OperationListView.ItemsSource = DB.entities.Operation.ToList();
        }
        public JobCardPage(User loginUser)
        {
            InitializeComponent();
            JobCardListView.ItemsSource = DB.entities.Job_card.ToList();
            OperationListView.ItemsSource = DB.entities.Operation.ToList();
            user = loginUser;
            if (user.Role_id == 7)
            {
                ProductPageButton.IsEnabled = false;
                WorkerPageButton.IsEnabled = false;
                OrderPageButton.IsEnabled = false;
                AddJobCardButton.IsEnabled = false;
                AddOperationButton.IsEnabled = false;
                EditOperationButton.IsEnabled = false;
                EditJobCardButton.IsEnabled = false;
            }
        }
        private void ReplaceKeywordWithValue(DocX document, string keyword, string value)
        {
            foreach (var paragraph in document.Paragraphs)
            {
                if (paragraph.Text.Contains(keyword))
                {
                    paragraph.ReplaceText(keyword, value);
                }
            }
        }

        private void WorkerPageButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new MainPage());
        }

        private void ProductPageButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ProductPage());
        }

        private void OrderPageButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new OrderPage());
        }

        private void GoBackButton_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Вы уверены, что хотите выйти из аккаунта?", "Выход", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                NavigationService.Navigate(new AuthPage());
            }
        }

        private void PrintButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (JobCardListView.SelectedItems != null && JobCardListView.SelectedItem != null)
                {
                    using (var templateDoc = DocX.Load(@"C:\Users\semyo\Desktop\PROMetellDoc\PROMetellDoc\Properties\Job_card_example.docx"))
                    {
                        var workplace = DB.entities.Workplace.First(c => c.Workplace_num == ((Job_card)JobCardListView.SelectedItem).Workplace_num);
                        string wp_Num = workplace.Workshop_num.ToString();
                        string area_Num = workplace.Area_num.ToString();
                        string jc_Num = ((Job_card)JobCardListView.SelectedItem).Job_card_num.ToString();
                        ReplaceKeywordWithValue(templateDoc, "{2}", wp_Num);
                        ReplaceKeywordWithValue(templateDoc, "{3}", area_Num);
                        ReplaceKeywordWithValue(templateDoc, "{5}", jc_Num);
                        var reportTable = templateDoc.Tables[1];
                        var rowPatternHigh = reportTable.Rows[2];
                        var rowPatternLow = reportTable.Rows[3];
                        int counter = 1;
                        var table_parts = DB.entities.Job_card_table_part.Where(c => c.Job_card_num == ((Job_card)JobCardListView.SelectedItem).Job_card_num);
                        foreach (var item in table_parts)
                        {
                            AddItemToTable(counter, reportTable, rowPatternHigh, rowPatternLow, item);
                            counter++;
                        }
                        rowPatternHigh.Remove();
                        rowPatternLow.Remove();
                        templateDoc.SaveAs($@"{Environment.GetFolderPath(Environment.SpecialFolder.Desktop)}\Наряд No_{jc_Num}");
                        MessageBox.Show("Наряд успешно сформирован. Вы можете найти его на рабочем столе.", "Формирование документа прошло успешно", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при создании документа: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private static void AddItemToTable(int number, Table table, Row rowPatternHigh, Row rowPatternLow, Job_card_table_part job_Card_Table_Part)
        {
            var newItemHigh = table.InsertRow(rowPatternHigh, table.RowCount - 1);
            newItemHigh.ReplaceText(new StringReplaceTextOptions() { SearchValue = "%NUMBER%", NewValue = number.ToString() });
            newItemHigh.ReplaceText(new StringReplaceTextOptions() { SearchValue = "%FIO%", NewValue = job_Card_Table_Part.Worker.Worker_lastname});
            newItemHigh.ReplaceText(new StringReplaceTextOptions() { SearchValue = "%CODE%", NewValue = job_Card_Table_Part.Worker_personnel_num});
            var newItemLow = table.InsertRow(rowPatternLow, table.RowCount - 1);
            newItemLow.ReplaceText(new StringReplaceTextOptions() { SearchValue = "%NAME%", NewValue = job_Card_Table_Part.Operation.Operation_name});
        }

        private void AddJobCardButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddEditJobCardPage());
        }

        public Job_card CurrentJC;

        private void JobCardListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            CurrentJC = (DataBase.Job_card)JobCardListView.SelectedItem;
        }

        private void EditJobCardButton_Click(object sender, RoutedEventArgs e)
        {
            if (CurrentJC != null)
            {
                NavigationService.Navigate(new AddEditJobCardPage(CurrentJC));
            }
            else
            {
                MessageBox.Show("Произошла ошибка. Пожалуйста, выберите запись перед тем, как приступить к редактированию.", "Ошибка редактирования записи", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void AddOperationButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddEditOperationPage());
        }

        public Operation CurrentOperation;

        private void OperationListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            CurrentOperation = (DataBase.Operation)OperationListView.SelectedItem;
        }

        private void EditOperationButton_Click(object sender, RoutedEventArgs e)
        {
            if (CurrentOperation != null)
            {
                NavigationService.Navigate(new AddEditOperationPage(CurrentOperation));
            }
            else
            {
                MessageBox.Show("Произошла ошибка. Пожалуйста, выберите запись перед тем, как приступить к редактированию.", "Ошибка редактирования записи", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void DeleteJobCardButton_Click(object sender, RoutedEventArgs e)
        {
            if (CurrentJC == null)
            {
                MessageBox.Show("Произошла ошибка. Пожалуйста, выберите запись, которую вы хотите удалить.", "Ошибка удаления записи", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
            else if (MessageBox.Show("Вы уверены, что хотите удалить запись?", "Удаление заказа", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    DataBase.Job_card jc = JobCardListView.SelectedItem as DataBase.Job_card;
                    DB.entities.Job_card_table_part.RemoveRange(jc.Job_card_table_part);
                    DB.entities.Job_card.Remove(jc);
                    DB.entities.SaveChanges();
                    MessageBox.Show("Запись успешно удалена.", "Запись удалена", MessageBoxButton.OK, MessageBoxImage.Information);
                    JobCardListView.ItemsSource = DB.entities.Job_card.ToList();
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка. Пожалуйста, повторите попытку позже.", "Неизвестная ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (SearchBox.Text != null && SearchBox.Text != "" && SearchBox.Text != " ")
            {
                JobCardListView.ItemsSource = DataBase.DB.entities.Job_card.Where(c => c.Product_code.Contains(SearchBox.Text)).ToList();
            }
            else
            {
                JobCardListView.ItemsSource = DataBase.DB.entities.Job_card.ToList();
            }
        }

        private void PrintDeliveryStickerButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (JobCardListView.SelectedItems != null && JobCardListView.SelectedItem != null)
                {
                    using (var templateDoc = DocX.Load(@"C:\Users\semyo\Desktop\PROMetellDoc II\PROMetellDoc\Properties\Sticker_example.docx"))
                    {
                        var product = DB.entities.Product.First(c => c.Product_code == ((Job_card)JobCardListView.SelectedItem).Product_code);
                        string product_code = product.Product_code.ToString();
                        string product_name = product.Product_name.ToString();
                        string jc_Num = ((Job_card)JobCardListView.SelectedItem).Job_card_num.ToString();
                        ReplaceKeywordWithValue(templateDoc, "{1}", Convert.ToString(product_code));
                        ReplaceKeywordWithValue(templateDoc, "{2}", product_name);
                        ReplaceKeywordWithValue(templateDoc, "{4}", jc_Num);
                        templateDoc.SaveAs($@"{Environment.GetFolderPath(Environment.SpecialFolder.Desktop)}\Стикер для отправки заказа No_{product_code}");
                        MessageBox.Show("Стикер успешно сформирован. Вы можете найти его на рабочем столе.", "Формирование документа прошло успешно", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при создании документа: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
