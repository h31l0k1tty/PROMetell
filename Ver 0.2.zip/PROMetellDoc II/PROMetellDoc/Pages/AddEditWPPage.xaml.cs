﻿using PROMetellDoc.DataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PROMetellDoc.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditWPPage.xaml
    /// </summary>
    public partial class AddEditWPPage : Page
    {
        Worker_position editWP;
        bool isExist = true;
        public AddEditWPPage()
        {
            InitializeComponent();
            isExist = false;
        }

        public AddEditWPPage(Worker_position WP)
        {
            InitializeComponent();
            editWP = WP;
            if (editWP != null)
            {
                WP_num_TextBox.IsEnabled = false;
            }
        }

        private void AddWPButton_Click(object sender, RoutedEventArgs e)
        {
            if (!isExist && WP_num_TextBox != null && WP_name_TextBox != null)
            {
                try
                {
                    DB.entities.Worker_position.Add(editWP);
                    DB.entities.SaveChanges();
                    MessageBox.Show("Должность успешно добавлена!", "Запись сохранена", MessageBoxButton.OK, MessageBoxImage.Information);
                    NavigationService.Navigate(new OrderPage());
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка, проверьте правильность заполнения полей.", "Запись не сохранена", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else if (WP_name_TextBox != null && WP_num_TextBox != null)
            {
                try
                {
                    DB.entities.SaveChanges();
                    MessageBox.Show("Информация о должности успешно изменена!", "Запись сохранена", MessageBoxButton.OK, MessageBoxImage.Information);
                    NavigationService.Navigate(new OrderPage());
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка, проверьте правильность заполнения полей.", "Запись не сохранена", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Запись не была сохранена всвязи с отсутствием данных в полях. Проверьте, все ли поля заполнены, и попробуйте снова.", "Ошибка сохранения данных", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void GoBackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new MainPage());
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            this.DataContext = editWP;
        }
    }
}
