﻿using PROMetellDoc.DataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PROMetellDoc.Pages
{
    /// <summary>
    /// Логика взаимодействия для OrderPage.xaml
    /// </summary>
    public partial class OrderPage : Page
    {
        public OrderPage()
        {
            InitializeComponent();
            OrderListView.ItemsSource = DataBase.DB.entities.Order.ToList();
        }

        private void ProductPageButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ProductPage());
        }

        private void WorkerPageButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new MainPage());
        }

        private void GoBackButton_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Вы уверены, что хотите выйти из аккаунта?", "Выход", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                NavigationService.Navigate(new AuthPage());
            }
        }
        public Order CurrentOrder;
        private void OrderListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            CurrentOrder = (DataBase.Order)OrderListView.SelectedItem;
        }

        private void AddOrderButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddEditOrderPage());
        }

        private void EditOrderButton_Click(object sender, RoutedEventArgs e)
        {
            if (CurrentOrder != null)
            {
                NavigationService.Navigate(new AddEditOrderPage(CurrentOrder));
            }
            else
            {
                MessageBox.Show("Произошла ошибка. Пожалуйста, выберите запись перед тем, как приступить к редактированию.", "Ошибка редактирования записи", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void JobCardPageButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new JobCardPage());
        }
    }
}
