﻿using PROMetellDoc.DataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PROMetellDoc.Pages
{
    /// <summary>
    /// Логика взаимодействия для AuthPage.xaml
    /// </summary>
    public partial class AuthPage : Page
    {
        public AuthPage()
        {
            InitializeComponent();
        }

        private void AuthButton_Click(object sender, RoutedEventArgs e)
        {
            User loginUser = DataBase.DB.entities.User.FirstOrDefault(c => c.User_login == LoginTextBox.Text && c.User_password == PasswordTextBox.Text);
            if (loginUser != null && loginUser.Role_id == 1)
            {
                NavigationService.Navigate(new JobCardPage());
            }
            else if (loginUser != null && loginUser.Role_id == 2)
            {
                NavigationService.Navigate(new MainPage());
            }
            else { MessageBox.Show("Произошла ошибка авторизации. Проверьте логин и пароль.", "Ошибка авторизации", MessageBoxButton.OK, MessageBoxImage.Error); }
        }
    }
}
