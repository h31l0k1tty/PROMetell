﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROMetellDoc.DataBase
{
    public class DB
    {
        public static PROMetellEntities entities = new PROMetellEntities();
    }
}
